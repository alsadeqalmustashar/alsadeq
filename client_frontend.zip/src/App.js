import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider, createTheme, Direction } from '@mui/material/styles';
import rtlPlugin from 'stylis-plugin-rtl';
import { CacheProvider } from '@emotion/react';
import createCache from '@emotion/cache';
import { prefixer } from 'stylis';
import CssBaseline from '@mui/material/CssBaseline';

// المكونات
import Header from './components/Header';
import Footer from './components/Footer';
import LoginScreen from './pages/LoginScreen';
import RegisterUserScreen from './pages/RegisterUserScreen';
import UserListScreen from './pages/UserListScreen';
import CourseListScreen from './pages/CourseListScreen';
import CourseCreateScreen from './pages/CourseCreateScreen';
import CourseDetailScreen from './pages/CourseDetailScreen';
import StudentCourseScreen from './pages/StudentCourseScreen';
import QuizScreen from './pages/QuizScreen';
import LiveSessionScreen from './pages/LiveSessionScreen';
import DashboardScreen from './pages/DashboardScreen';
import ProfileScreen from './pages/ProfileScreen';
import NotFoundScreen from './pages/NotFoundScreen';

// مكونات إضافية
import LanguageSelector from './components/LanguageSelector';
import ProtectedRoute from './components/ProtectedRoute';
import AdminRoute from './components/AdminRoute';
import InstructorRoute from './components/InstructorRoute';
import StudentRoute from './components/StudentRoute';

// سياق اللغة
import { LanguageProvider } from './contexts/LanguageContext';

// إنشاء مخزن التخزين المؤقت للغة العربية
const cacheRtl = createCache({
  key: 'muirtl',
  stylisPlugins: [prefixer, rtlPlugin],
});

// إنشاء مخزن التخزين المؤقت للغة الإنجليزية
const cacheLtr = createCache({
  key: 'muiltr',
  stylisPlugins: [prefixer],
});

const App = () => {
  const [direction, setDirection] = useState('rtl');
  const [language, setLanguage] = useState('ar');
  
  // إنشاء السمة حسب اتجاه اللغة
  const theme = createTheme({
    direction: direction,
    palette: {
      primary: {
        main: '#1976d2',
      },
      secondary: {
        main: '#dc004e',
      },
    },
    typography: {
      fontFamily: language === 'ar' ? 
        '"Tajawal", "Roboto", "Helvetica", "Arial", sans-serif' : 
        '"Roboto", "Helvetica", "Arial", sans-serif',
    },
  });

  // تغيير اللغة
  const handleLanguageChange = (newLanguage) => {
    setLanguage(newLanguage);
    setDirection(newLanguage === 'ar' ? 'rtl' : 'ltr');
    // تخزين اللغة المفضلة في التخزين المحلي
    localStorage.setItem('preferredLanguage', newLanguage);
  };

  // تحميل اللغة المفضلة من التخزين المحلي عند بدء التشغيل
  useEffect(() => {
    const savedLanguage = localStorage.getItem('preferredLanguage');
    if (savedLanguage) {
      setLanguage(savedLanguage);
      setDirection(savedLanguage === 'ar' ? 'rtl' : 'ltr');
    }
  }, []);

  return (
    <LanguageProvider value={{ language, setLanguage: handleLanguageChange }}>
      <CacheProvider value={direction === 'rtl' ? cacheRtl : cacheLtr}>
        <ThemeProvider theme={theme}>
          <CssBaseline />
          <Router>
            <div dir={direction} style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
              <Header />
              <main style={{ flex: 1, padding: '20px 0' }}>
                <Routes>
                  {/* المسارات العامة */}
                  <Route path="/login" element={<LoginScreen />} />
                  <Route path="/" element={<Navigate to="/dashboard" replace />} />
                  
                  {/* مسارات المستخدمين المسجلين */}
                  <Route path="/dashboard" element={
                    <ProtectedRoute>
                      <DashboardScreen />
                    </ProtectedRoute>
                  } />
                  <Route path="/profile" element={
                    <ProtectedRoute>
                      <ProfileScreen />
                    </ProtectedRoute>
                  } />
                  
                  {/* مسارات المسؤول */}
                  <Route path="/admin/users" element={
                    <AdminRoute>
                      <UserListScreen />
                    </AdminRoute>
                  } />
                  <Route path="/admin/user/register" element={
                    <AdminRoute>
                      <RegisterUserScreen />
                    </AdminRoute>
                  } />
                  
                  {/* مسارات المدرب */}
                  <Route path="/courses" element={
                    <InstructorRoute>
                      <CourseListScreen />
                    </InstructorRoute>
                  } />
                  <Route path="/course/create" element={
                    <InstructorRoute>
                      <CourseCreateScreen />
                    </InstructorRoute>
                  } />
                  <Route path="/course/:id" element={
                    <InstructorRoute>
                      <CourseDetailScreen />
                    </InstructorRoute>
                  } />
                  <Route path="/course/:id/edit" element={
                    <InstructorRoute>
                      <CourseCreateScreen />
                    </InstructorRoute>
                  } />
                  
                  {/* مسارات الطالب */}
                  <Route path="/student/course/:id" element={
                    <StudentRoute>
                      <StudentCourseScreen />
                    </StudentRoute>
                  } />
                  <Route path="/quiz/:id" element={
                    <StudentRoute>
                      <QuizScreen />
                    </StudentRoute>
                  } />
                  
                  {/* مسارات البث المباشر */}
                  <Route path="/live-session/:id" element={
                    <ProtectedRoute>
                      <LiveSessionScreen />
                    </ProtectedRoute>
                  } />
                  
                  {/* مسار غير موجود */}
                  <Route path="*" element={<NotFoundScreen />} />
                </Routes>
              </main>
              <Footer />
              
              {/* محدد اللغة */}
              <LanguageSelector 
                currentLanguage={language} 
                onLanguageChange={handleLanguageChange} 
              />
            </div>
          </Router>
        </ThemeProvider>
      </CacheProvider>
    </LanguageProvider>
  );
};

export default App;
