import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import { LanguageProvider } from '../contexts/LanguageContext';
import LoginScreen from '../pages/LoginScreen';
import RegisterUserScreen from '../pages/RegisterUserScreen';
import UserListScreen from '../pages/UserListScreen';

// إعداد متجر وهمي
const middlewares = [thunk];
const mockStore = configureStore(middlewares);

// اختبارات شاشة تسجيل الدخول
describe('LoginScreen', () => {
  let store;
  
  beforeEach(() => {
    store = mockStore({
      userLogin: {
        loading: false,
        error: null,
        userInfo: null
      }
    });
  });
  
  test('يعرض نموذج تسجيل الدخول', () => {
    const languageValue = { language: 'ar', setLanguage: jest.fn() };
    
    render(
      <Provider store={store}>
        <BrowserRouter>
          <LanguageProvider value={languageValue}>
            <LoginScreen />
          </LanguageProvider>
        </BrowserRouter>
      </Provider>
    );
    
    expect(screen.getByLabelText(/اسم المستخدم/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/كلمة المرور/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /تسجيل الدخول/i })).toBeInTheDocument();
  });
  
  test('يعرض رسالة خطأ عند إدخال بيانات غير صحيحة', async () => {
    const languageValue = { language: 'ar', setLanguage: jest.fn() };
    
    render(
      <Provider store={store}>
        <BrowserRouter>
          <LanguageProvider value={languageValue}>
            <LoginScreen />
          </LanguageProvider>
        </BrowserRouter>
      </Provider>
    );
    
    fireEvent.change(screen.getByLabelText(/اسم المستخدم/i), { target: { value: '' } });
    fireEvent.change(screen.getByLabelText(/كلمة المرور/i), { target: { value: '' } });
    fireEvent.click(screen.getByRole('button', { name: /تسجيل الدخول/i }));
    
    await waitFor(() => {
      expect(screen.getByText(/اسم المستخدم مطلوب/i)).toBeInTheDocument();
      expect(screen.getByText(/كلمة المرور مطلوبة/i)).toBeInTheDocument();
    });
  });
});

// اختبارات شاشة تسجيل المستخدمين
describe('RegisterUserScreen', () => {
  let store;
  
  beforeEach(() => {
    store = mockStore({
      userLogin: {
        userInfo: {
          _id: '1',
          fullName: 'صادق زيدان',
          role: 'admin'
        }
      },
      userRegister: {
        loading: false,
        error: null,
        success: false
      }
    });
  });
  
  test('يعرض نموذج تسجيل المستخدمين', () => {
    const languageValue = { language: 'ar', setLanguage: jest.fn() };
    
    render(
      <Provider store={store}>
        <BrowserRouter>
          <LanguageProvider value={languageValue}>
            <RegisterUserScreen />
          </LanguageProvider>
        </BrowserRouter>
      </Provider>
    );
    
    expect(screen.getByLabelText(/الاسم الكامل/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/البريد الإلكتروني/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/اسم المستخدم/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/كلمة المرور/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/تأكيد كلمة المرور/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/الدور/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/الحالة/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /إنشاء مستخدم جديد/i })).toBeInTheDocument();
  });
  
  test('يتحقق من تطابق كلمات المرور', async () => {
    const languageValue = { language: 'ar', setLanguage: jest.fn() };
    
    render(
      <Provider store={store}>
        <BrowserRouter>
          <LanguageProvider value={languageValue}>
            <RegisterUserScreen />
          </LanguageProvider>
        </BrowserRouter>
      </Provider>
    );
    
    fireEvent.change(screen.getByLabelText(/الاسم الكامل/i), { target: { value: 'محمد أحمد' } });
    fireEvent.change(screen.getByLabelText(/البريد الإلكتروني/i), { target: { value: 'mohammed@example.com' } });
    fireEvent.change(screen.getByLabelText(/اسم المستخدم/i), { target: { value: 'mohammed' } });
    fireEvent.change(screen.getByLabelText(/كلمة المرور/i), { target: { value: 'password123' } });
    fireEvent.change(screen.getByLabelText(/تأكيد كلمة المرور/i), { target: { value: 'password456' } });
    fireEvent.click(screen.getByRole('button', { name: /إنشاء مستخدم جديد/i }));
    
    await waitFor(() => {
      expect(screen.getByText(/كلمات المرور غير متطابقة/i)).toBeInTheDocument();
    });
  });
});

// اختبارات شاشة قائمة المستخدمين
describe('UserListScreen', () => {
  let store;
  
  beforeEach(() => {
    store = mockStore({
      userLogin: {
        userInfo: {
          _id: '1',
          fullName: 'صادق زيدان',
          role: 'admin'
        }
      },
      userList: {
        loading: false,
        error: null,
        users: [
          {
            _id: '1',
            fullName: 'صادق زيدان',
            username: 'sadeq',
            email: 'sadeq@example.com',
            role: 'admin',
            status: 'active',
            lastLogin: new Date().toISOString()
          },
          {
            _id: '2',
            fullName: 'أحمد محمد',
            username: 'ahmed',
            email: 'ahmed@example.com',
            role: 'instructor',
            status: 'active',
            lastLogin: new Date().toISOString()
          }
        ]
      }
    });
  });
  
  test('يعرض قائمة المستخدمين', () => {
    const languageValue = { language: 'ar', setLanguage: jest.fn() };
    
    render(
      <Provider store={store}>
        <BrowserRouter>
          <LanguageProvider value={languageValue}>
            <UserListScreen />
          </LanguageProvider>
        </BrowserRouter>
      </Provider>
    );
    
    expect(screen.getByText(/قائمة المستخدمين/i)).toBeInTheDocument();
    expect(screen.getByText(/صادق زيدان/i)).toBeInTheDocument();
    expect(screen.getByText(/أحمد محمد/i)).toBeInTheDocument();
    expect(screen.getByText(/sadeq/i)).toBeInTheDocument();
    expect(screen.getByText(/ahmed/i)).toBeInTheDocument();
  });
  
  test('يمكن البحث عن المستخدمين', async () => {
    const languageValue = { language: 'ar', setLanguage: jest.fn() };
    
    render(
      <Provider store={store}>
        <BrowserRouter>
          <LanguageProvider value={languageValue}>
            <UserListScreen />
          </LanguageProvider>
        </BrowserRouter>
      </Provider>
    );
    
    fireEvent.change(screen.getByPlaceholderText(/بحث/i), { target: { value: 'أحمد' } });
    
    await waitFor(() => {
      expect(screen.getByText(/أحمد محمد/i)).toBeInTheDocument();
      expect(screen.queryByText(/صادق زيدان/i)).not.toBeInTheDocument();
    });
  });
});

// اختبارات أمان المنصة
describe('Platform Security', () => {
  test('يتم تشفير كلمات المرور', () => {
    // هذا اختبار وهمي، في التطبيق الفعلي سيتم اختبار تشفير كلمات المرور في الخادم
    const password = 'password123';
    const hashedPassword = 'hashed_password'; // في الواقع سيكون هذا ناتج دالة التشفير
    
    expect(hashedPassword).not.toBe(password);
  });
  
  test('يتم التحقق من صلاحيات المستخدم', () => {
    // هذا اختبار وهمي، في التطبيق الفعلي سيتم اختبار التحقق من الصلاحيات
    const userRole = 'student';
    const requiredRole = 'admin';
    
    expect(userRole).not.toBe(requiredRole);
  });
});
