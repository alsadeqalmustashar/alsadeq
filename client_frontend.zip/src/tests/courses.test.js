import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import { LanguageProvider } from '../contexts/LanguageContext';
import CourseListScreen from '../pages/CourseListScreen';
import CourseCreateScreen from '../pages/CourseCreateScreen';
import StudentCourseScreen from '../pages/StudentCourseScreen';
import QuizScreen from '../pages/QuizScreen';

// إعداد متجر وهمي
const middlewares = [thunk];
const mockStore = configureStore(middlewares);

// اختبارات شاشة قائمة الدورات
describe('CourseListScreen', () => {
  let store;
  
  beforeEach(() => {
    store = mockStore({
      userLogin: {
        userInfo: {
          _id: '1',
          fullName: 'صادق زيدان',
          role: 'instructor'
        }
      },
      courseList: {
        loading: false,
        error: null,
        courses: [
          {
            _id: 'c1',
            title: {
              ar: 'مبادئ إدارة المبيعات',
              en: 'Sales Management Principles'
            },
            description: {
              ar: 'دورة شاملة في مبادئ إدارة المبيعات',
              en: 'Comprehensive course in sales management principles'
            },
            instructor: {
              _id: '1',
              fullName: 'صادق زيدان'
            },
            status: 'published',
            enrolledStudents: 15
          },
          {
            _id: 'c2',
            title: {
              ar: 'استراتيجيات التسويق الرقمي',
              en: 'Digital Marketing Strategies'
            },
            description: {
              ar: 'دورة متقدمة في استراتيجيات التسويق الرقمي',
              en: 'Advanced course in digital marketing strategies'
            },
            instructor: {
              _id: '1',
              fullName: 'صادق زيدان'
            },
            status: 'draft',
            enrolledStudents: 0
          }
        ]
      }
    });
  });
  
  test('يعرض قائمة الدورات', () => {
    const languageValue = { language: 'ar', setLanguage: jest.fn() };
    
    render(
      <Provider store={store}>
        <BrowserRouter>
          <LanguageProvider value={languageValue}>
            <CourseListScreen />
          </LanguageProvider>
        </BrowserRouter>
      </Provider>
    );
    
    expect(screen.getByText(/قائمة الدورات/i)).toBeInTheDocument();
    expect(screen.getByText(/مبادئ إدارة المبيعات/i)).toBeInTheDocument();
    expect(screen.getByText(/استراتيجيات التسويق الرقمي/i)).toBeInTheDocument();
  });
  
  test('يمكن تصفية الدورات حسب الحالة', async () => {
    const languageValue = { language: 'ar', setLanguage: jest.fn() };
    
    render(
      <Provider store={store}>
        <BrowserRouter>
          <LanguageProvider value={languageValue}>
            <CourseListScreen />
          </LanguageProvider>
        </BrowserRouter>
      </Provider>
    );
    
    fireEvent.click(screen.getByText(/منشورة/i));
    
    await waitFor(() => {
      expect(screen.getByText(/مبادئ إدارة المبيعات/i)).toBeInTheDocument();
      expect(screen.queryByText(/استراتيجيات التسويق الرقمي/i)).not.toBeInTheDocument();
    });
  });
});

// اختبارات شاشة إنشاء الدورة
describe('CourseCreateScreen', () => {
  let store;
  
  beforeEach(() => {
    store = mockStore({
      userLogin: {
        userInfo: {
          _id: '1',
          fullName: 'صادق زيدان',
          role: 'instructor'
        }
      },
      courseCreate: {
        loading: false,
        error: null,
        success: false
      }
    });
  });
  
  test('يعرض نموذج إنشاء الدورة', () => {
    const languageValue = { language: 'ar', setLanguage: jest.fn() };
    
    render(
      <Provider store={store}>
        <BrowserRouter>
          <LanguageProvider value={languageValue}>
            <CourseCreateScreen />
          </LanguageProvider>
        </BrowserRouter>
      </Provider>
    );
    
    expect(screen.getByText(/إنشاء دورة جديدة/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/العنوان \(العربية\)/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/العنوان \(الإنجليزية\)/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/الوصف \(العربية\)/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/الوصف \(الإنجليزية\)/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/الحالة/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /إنشاء/i })).toBeInTheDocument();
  });
  
  test('يتحقق من إدخال العنوان', async () => {
    const languageValue = { language: 'ar', setLanguage: jest.fn() };
    
    render(
      <Provider store={store}>
        <BrowserRouter>
          <LanguageProvider value={languageValue}>
            <CourseCreateScreen />
          </LanguageProvider>
        </BrowserRouter>
      </Provider>
    );
    
    fireEvent.change(screen.getByLabelText(/العنوان \(العربية\)/i), { target: { value: '' } });
    fireEvent.click(screen.getByRole('button', { name: /إنشاء/i }));
    
    await waitFor(() => {
      expect(screen.getByText(/العنوان مطلوب/i)).toBeInTheDocument();
    });
  });
});

// اختبارات شاشة عرض الدورة للطالب
describe('StudentCourseScreen', () => {
  let store;
  
  beforeEach(() => {
    store = mockStore({
      userLogin: {
        userInfo: {
          _id: '101',
          fullName: 'أحمد محمد',
          role: 'student'
        }
      },
      courseDetails: {
        loading: false,
        error: null,
        course: {
          _id: 'c1',
          title: {
            ar: 'مبادئ إدارة المبيعات',
            en: 'Sales Management Principles'
          },
          description: {
            ar: 'دورة شاملة في مبادئ إدارة المبيعات',
            en: 'Comprehensive course in sales management principles'
          },
          instructor: {
            _id: '1',
            fullName: 'صادق زيدان'
          },
          modules: [
            {
              _id: 'm1',
              title: {
                ar: 'مقدمة في إدارة المبيعات',
                en: 'Introduction to Sales Management'
              },
              description: {
                ar: 'مقدمة عامة حول إدارة المبيعات وأهميتها',
                en: 'General introduction to sales management and its importance'
              },
              order: 1,
              contents: [
                {
                  _id: 'cnt1',
                  type: 'video',
                  title: {
                    ar: 'مفهوم إدارة المبيعات',
                    en: 'Sales Management Concept'
                  },
                  fileUrl: 'https://example.com/video1.mp4',
                  duration: 15
                },
                {
                  _id: 'cnt2',
                  type: 'pdf',
                  title: {
                    ar: 'ملخص المحاضرة',
                    en: 'Lecture Summary'
                  },
                  fileUrl: 'https://example.com/summary1.pdf'
                }
              ]
            }
          ]
        }
      },
      studentProgress: {
        loading: false,
        error: null,
        progress: {
          courseId: 'c1',
          completedContents: ['cnt1'],
          quizAttempts: []
        }
      }
    });
  });
  
  test('يعرض محتوى الدورة للطالب', () => {
    const languageValue = { language: 'ar', setLanguage: jest.fn() };
    
    render(
      <Provider store={store}>
        <BrowserRouter>
          <LanguageProvider value={languageValue}>
            <StudentCourseScreen />
          </LanguageProvider>
        </BrowserRouter>
      </Provider>
    );
    
    expect(screen.getByText(/مبادئ إدارة المبيعات/i)).toBeInTheDocument();
    expect(screen.getByText(/مقدمة في إدارة المبيعات/i)).toBeInTheDocument();
    expect(screen.getByText(/مفهوم إدارة المبيعات/i)).toBeInTheDocument();
    expect(screen.getByText(/ملخص المحاضرة/i)).toBeInTheDocument();
  });
  
  test('يعرض تقدم الطالب في الدورة', () => {
    const languageValue = { language: 'ar', setLanguage: jest.fn() };
    
    render(
      <Provider store={store}>
        <BrowserRouter>
          <LanguageProvider value={languageValue}>
            <StudentCourseScreen />
          </LanguageProvider>
        </BrowserRouter>
      </Provider>
    );
    
    expect(screen.getByText(/تقدمك في الدورة/i)).toBeInTheDocument();
    expect(screen.getByText(/50%/i)).toBeInTheDocument(); // 1 من أصل 2 محتوى مكتمل
  });
});

// اختبارات شاشة الاختبار
describe('QuizScreen', () => {
  let store;
  
  beforeEach(() => {
    store = mockStore({
      userLogin: {
        userInfo: {
          _id: '101',
          fullName: 'أحمد محمد',
          role: 'student'
        }
      },
      quizDetails: {
        loading: false,
        error: null,
        quiz: {
          _id: 'q1',
          title: {
            ar: 'اختبار استراتيجيات البيع',
            en: 'Sales Strategies Quiz'
          },
          description: {
            ar: 'اختبار لقياس فهم استراتيجيات البيع',
            en: 'Quiz to measure understanding of sales strategies'
          },
          passingScore: 70,
          timeLimit: 10,
          questions: [
            {
              _id: 'q1',
              type: 'single',
              text: {
                ar: 'ما هي أفضل استراتيجية للمبيعات للمنتجات ذات القيمة العالية؟',
                en: 'What is the best sales strategy for high-value products?'
              },
              options: [
                {
                  ar: 'البيع المباشر',
                  en: 'Direct selling'
                },
                {
                  ar: 'البيع عبر الإنترنت',
                  en: 'Online selling'
                },
                {
                  ar: 'البيع الاستشاري',
                  en: 'Consultative selling'
                },
                {
                  ar: 'البيع بالتجزئة',
                  en: 'Retail selling'
                }
              ],
              points: 10
            }
          ]
        }
      }
    });
  });
  
  test('يعرض شاشة بدء الاختبار', () => {
    const languageValue = { language: 'ar', setLanguage: jest.fn() };
    
    render(
      <Provider store={store}>
        <BrowserRouter>
          <LanguageProvider value={languageValue}>
            <QuizScreen />
          </LanguageProvider>
        </BrowserRouter>
      </Provider>
    );
    
    expect(screen.getByText(/اختبار استراتيجيات البيع/i)).toBeInTheDocument();
    expect(screen.getByText(/اختبار لقياس فهم استراتيجيات البيع/i)).toBeInTheDocument();
    expect(screen.getByText(/درجة النجاح: 70%/i)).toBeInTheDocument();
    expect(screen.getByText(/الوقت المخصص: 10 دقيقة/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /بدء الاختبار/i })).toBeInTheDocument();
  });
  
  test('يبدأ الاختبار عند النقر على زر البدء', async () => {
    const languageValue = { language: 'ar', setLanguage: jest.fn() };
    
    render(
      <Provider store={store}>
        <BrowserRouter>
          <LanguageProvider value={languageValue}>
            <QuizScreen />
          </LanguageProvider>
        </BrowserRouter>
      </Provider>
    );
    
    fireEvent.click(screen.getByRole('button', { name: /بدء الاختبار/i }));
    
    await waitFor(() => {
      expect(screen.getByText(/ما هي أفضل استراتيجية للمبيعات للمنتجات ذات القيمة العالية؟/i)).toBeInTheDocument();
      expect(screen.getByText(/البيع المباشر/i)).toBeInTheDocument();
      expect(screen.getByText(/البيع عبر الإنترنت/i)).toBeInTheDocument();
      expect(screen.getByText(/البيع الاستشاري/i)).toBeInTheDocument();
      expect(screen.getByText(/البيع بالتجزئة/i)).toBeInTheDocument();
      expect(screen.getByRole('button', { name: /تقديم الاختبار/i })).toBeInTheDocument();
    });
  });
});

// اختبارات أداء المنصة
describe('Platform Performance', () => {
  test('يتم تحميل الصفحات بسرعة مناسبة', () => {
    // هذا اختبار وهمي، في التطبيق الفعلي سيتم قياس وقت التحميل
    const loadTime = 500; // بالمللي ثانية
    const maxAcceptableLoadTime = 1000; // بالمللي ثانية
    
    expect(loadTime).toBeLessThan(maxAcceptableLoadTime);
  });
  
  test('يتم تحميل الفيديوهات بشكل سلس', () => {
    // هذا اختبار وهمي، في التطبيق الفعلي سيتم اختبار تحميل الفيديوهات
    const bufferingTime = 200; // بالمللي ثانية
    const maxAcceptableBufferingTime = 500; // بالمللي ثانية
    
    expect(bufferingTime).toBeLessThan(maxAcceptableBufferingTime);
  });
});
