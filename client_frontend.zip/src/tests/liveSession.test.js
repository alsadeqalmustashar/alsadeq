import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import { Provider } from 'react-redux';
import { BrowserRouter } from 'react-router-dom';
import configureStore from 'redux-mock-store';
import thunk from 'redux-thunk';
import { LanguageProvider } from '../contexts/LanguageContext';
import LiveSessionScreen from '../pages/LiveSessionScreen';

// إعداد متجر وهمي
const middlewares = [thunk];
const mockStore = configureStore(middlewares);

// اختبارات شاشة البث المباشر
describe('LiveSessionScreen', () => {
  let store;
  
  beforeEach(() => {
    store = mockStore({
      userLogin: {
        userInfo: {
          _id: '101',
          fullName: 'أحمد محمد',
          role: 'student'
        }
      },
      liveSessionDetails: {
        loading: false,
        error: null,
        session: {
          _id: 'ls1',
          title: {
            ar: 'استراتيجيات المبيعات المتقدمة - جلسة مباشرة',
            en: 'Advanced Sales Strategies - Live Session'
          },
          description: {
            ar: 'جلسة تفاعلية لمناقشة استراتيجيات المبيعات المتقدمة وتطبيقاتها',
            en: 'Interactive session to discuss advanced sales strategies and their applications'
          },
          instructor: {
            _id: '1',
            fullName: 'صادق زيدان',
            avatar: 'https://via.placeholder.com/150'
          },
          courseId: 'c1',
          courseName: {
            ar: 'مبادئ إدارة المبيعات',
            en: 'Sales Management Principles'
          },
          startTime: new Date(Date.now() - 10 * 60 * 1000).toISOString(),
          endTime: new Date(Date.now() + 50 * 60 * 1000).toISOString(),
          status: 'active',
          recordingEnabled: true
        }
      },
      liveSessionParticipants: {
        loading: false,
        error: null,
        participants: [
          {
            _id: '1',
            fullName: 'صادق زيدان',
            role: 'instructor',
            avatar: 'https://via.placeholder.com/150',
            isActive: true,
            joinedAt: new Date(Date.now() - 10 * 60 * 1000).toISOString()
          },
          {
            _id: '101',
            fullName: 'أحمد محمد',
            role: 'student',
            avatar: 'https://via.placeholder.com/150',
            isActive: true,
            joinedAt: new Date(Date.now() - 8 * 60 * 1000).toISOString()
          },
          {
            _id: '102',
            fullName: 'سارة علي',
            role: 'student',
            avatar: 'https://via.placeholder.com/150',
            isActive: true,
            joinedAt: new Date(Date.now() - 5 * 60 * 1000).toISOString()
          }
        ]
      },
      liveSessionMessages: {
        loading: false,
        error: null,
        messages: [
          {
            _id: 'm1',
            sender: {
              _id: '1',
              fullName: 'صادق زيدان',
              role: 'instructor',
              avatar: 'https://via.placeholder.com/150'
            },
            text: 'مرحباً بكم جميعاً في هذه الجلسة المباشرة حول استراتيجيات المبيعات المتقدمة.',
            timestamp: new Date(Date.now() - 9 * 60 * 1000).toISOString()
          },
          {
            _id: 'm2',
            sender: {
              _id: '101',
              fullName: 'أحمد محمد',
              role: 'student',
              avatar: 'https://via.placeholder.com/150'
            },
            text: 'شكراً لك أستاذ صادق، متحمس للجلسة.',
            timestamp: new Date(Date.now() - 8.5 * 60 * 1000).toISOString()
          }
        ]
      }
    });
  });
  
  test('يعرض معلومات الجلسة المباشرة', () => {
    const languageValue = { language: 'ar', setLanguage: jest.fn() };
    
    render(
      <Provider store={store}>
        <BrowserRouter>
          <LanguageProvider value={languageValue}>
            <LiveSessionScreen />
          </LanguageProvider>
        </BrowserRouter>
      </Provider>
    );
    
    expect(screen.getByText(/استراتيجيات المبيعات المتقدمة - جلسة مباشرة/i)).toBeInTheDocument();
    expect(screen.getByText(/جلسة تفاعلية لمناقشة استراتيجيات المبيعات المتقدمة وتطبيقاتها/i)).toBeInTheDocument();
    expect(screen.getByText(/المدرب: صادق زيدان/i)).toBeInTheDocument();
    expect(screen.getByText(/الدورة: مبادئ إدارة المبيعات/i)).toBeInTheDocument();
  });
  
  test('يعرض الدردشة والمشاركين', () => {
    const languageValue = { language: 'ar', setLanguage: jest.fn() };
    
    render(
      <Provider store={store}>
        <BrowserRouter>
          <LanguageProvider value={languageValue}>
            <LiveSessionScreen />
          </LanguageProvider>
        </BrowserRouter>
      </Provider>
    );
    
    expect(screen.getByText(/الدردشة/i)).toBeInTheDocument();
    expect(screen.getByText(/المشاركون/i)).toBeInTheDocument();
    expect(screen.getByText(/مرحباً بكم جميعاً في هذه الجلسة المباشرة حول استراتيجيات المبيعات المتقدمة./i)).toBeInTheDocument();
    expect(screen.getByText(/شكراً لك أستاذ صادق، متحمس للجلسة./i)).toBeInTheDocument();
    
    // التبديل إلى تبويب المشاركين
    fireEvent.click(screen.getByText(/المشاركون/i));
    
    expect(screen.getByText(/المشاركون \(3\)/i)).toBeInTheDocument();
    expect(screen.getByText(/صادق زيدان \(المدرب\)/i)).toBeInTheDocument();
    expect(screen.getByText(/أحمد محمد/i)).toBeInTheDocument();
    expect(screen.getByText(/سارة علي/i)).toBeInTheDocument();
  });
  
  test('يمكن إرسال رسالة في الدردشة', async () => {
    const languageValue = { language: 'ar', setLanguage: jest.fn() };
    
    render(
      <Provider store={store}>
        <BrowserRouter>
          <LanguageProvider value={languageValue}>
            <LiveSessionScreen />
          </LanguageProvider>
        </BrowserRouter>
      </Provider>
    );
    
    fireEvent.change(screen.getByPlaceholderText(/اكتب رسالتك هنا/i), { target: { value: 'هل يمكن شرح استراتيجية البيع الاستشاري بمزيد من التفصيل؟' } });
    fireEvent.click(screen.getByRole('button', { name: /إرسال/i }));
    
    await waitFor(() => {
      expect(screen.getByText(/هل يمكن شرح استراتيجية البيع الاستشاري بمزيد من التفصيل؟/i)).toBeInTheDocument();
    });
  });
  
  test('يمكن الانضمام إلى الجلسة ومغادرتها', async () => {
    const languageValue = { language: 'ar', setLanguage: jest.fn() };
    
    render(
      <Provider store={store}>
        <BrowserRouter>
          <LanguageProvider value={languageValue}>
            <LiveSessionScreen />
          </LanguageProvider>
        </BrowserRouter>
      </Provider>
    );
    
    // المستخدم منضم بالفعل، لذا نتوقع وجود زر المغادرة
    expect(screen.getByRole('button', { name: /مغادرة الجلسة/i })).toBeInTheDocument();
    
    // النقر على زر المغادرة
    fireEvent.click(screen.getByRole('button', { name: /مغادرة الجلسة/i }));
    
    await waitFor(() => {
      expect(screen.getByRole('button', { name: /انضمام إلى الجلسة/i })).toBeInTheDocument();
    });
    
    // النقر على زر الانضمام
    fireEvent.click(screen.getByRole('button', { name: /انضمام إلى الجلسة/i }));
    
    await waitFor(() => {
      expect(screen.getByRole('button', { name: /مغادرة الجلسة/i })).toBeInTheDocument();
    });
  });
});

// اختبارات أمان البث المباشر
describe('Live Session Security', () => {
  test('يتم التحقق من صلاحيات المستخدم للانضمام إلى الجلسة', () => {
    // هذا اختبار وهمي، في التطبيق الفعلي سيتم اختبار التحقق من الصلاحيات
    const userRole = 'student';
    const isEnrolledInCourse = true;
    const canJoinSession = userRole === 'student' && isEnrolledInCourse;
    
    expect(canJoinSession).toBe(true);
  });
  
  test('يتم تشفير اتصال البث المباشر', () => {
    // هذا اختبار وهمي، في التطبيق الفعلي سيتم اختبار تشفير الاتصال
    const isConnectionEncrypted = true;
    
    expect(isConnectionEncrypted).toBe(true);
  });
});

// اختبارات أداء البث المباشر
describe('Live Session Performance', () => {
  test('يتم تحميل البث المباشر بجودة مناسبة', () => {
    // هذا اختبار وهمي، في التطبيق الفعلي سيتم اختبار جودة البث
    const streamQuality = 'high';
    const acceptableQualities = ['medium', 'high'];
    
    expect(acceptableQualities).toContain(streamQuality);
  });
  
  test('يتم إرسال واستقبال الرسائل في الوقت المناسب', () => {
    // هذا اختبار وهمي، في التطبيق الفعلي سيتم اختبار وقت الاستجابة
    const messageDeliveryTime = 200; // بالمللي ثانية
    const maxAcceptableDeliveryTime = 500; // بالمللي ثانية
    
    expect(messageDeliveryTime).toBeLessThan(maxAcceptableDeliveryTime);
  });
});
