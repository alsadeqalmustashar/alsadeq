import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Box,
  Container,
  Paper,
  Typography,
  CircularProgress,
  Alert,
  Tabs,
  Tab,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Divider,
  Button,
  Grid,
  Card,
  CardContent,
  LinearProgress
} from '@mui/material';
import {
  PlayCircleOutline as VideoIcon,
  PictureAsPdf as PdfIcon,
  Quiz as QuizIcon,
  CheckCircle as CompletedIcon,
  RadioButtonUnchecked as IncompleteIcon
} from '@mui/icons-material';

// سيتم استبدال هذا بإجراءات Redux الفعلية
const getCourseDetails = (id) => ({ type: 'GET_COURSE_DETAILS_REQUEST', payload: id });
const getModuleDetails = (id) => ({ type: 'GET_MODULE_DETAILS_REQUEST', payload: id });
const markContentAsCompleted = (courseId, moduleId, contentIndex) => ({ 
  type: 'MARK_CONTENT_COMPLETED_REQUEST', 
  payload: { courseId, moduleId, contentIndex } 
});

const StudentCourseScreen = () => {
  const { id: courseId } = useParams();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  
  // سيتم استبدال هذا بحالة Redux الفعلية
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [course, setCourse] = useState(null);
  const [modules, setModules] = useState([]);
  const [studentProgress, setStudentProgress] = useState(null);
  
  const userLogin = useSelector((state) => state.userLogin);
  const { userInfo } = userLogin;

  // حالة الواجهة
  const [selectedModuleIndex, setSelectedModuleIndex] = useState(0);
  const [selectedContentIndex, setSelectedContentIndex] = useState(0);
  const [activeContent, setActiveContent] = useState(null);

  // التحقق من صلاحيات المستخدم وتحميل تفاصيل الدورة
  useEffect(() => {
    if (!userInfo) {
      navigate('/login');
    } else if (userInfo.role !== 'student') {
      navigate('/dashboard');
    } else {
      dispatch(getCourseDetails(courseId));
      
      // محاكاة تحميل البيانات (سيتم استبداله بالمنطق الفعلي)
      setLoading(true);
      setTimeout(() => {
        setCourse({
          _id: courseId,
          title: {
            ar: 'مبادئ إدارة المبيعات',
            en: 'Sales Management Principles'
          },
          description: {
            ar: 'دورة شاملة في أساسيات إدارة المبيعات وتطوير استراتيجيات البيع',
            en: 'Comprehensive course in sales management fundamentals and strategy development'
          },
          instructor: {
            _id: '1',
            fullName: 'صادق زيدان'
          },
          thumbnail: 'https://via.placeholder.com/300x200?text=Sales+Management',
          isPublished: true,
          enrolledStudents: ['101', '102', '103'],
        });
        
        setModules([
          {
            _id: 'm1',
            title: {
              ar: 'مقدمة في إدارة المبيعات',
              en: 'Introduction to Sales Management'
            },
            description: {
              ar: 'نظرة عامة على مفاهيم إدارة المبيعات',
              en: 'Overview of sales management concepts'
            },
            order: 1,
            content: [
              {
                _id: 'c1',
                type: 'video',
                title: {
                  ar: 'مقدمة الدورة',
                  en: 'Course Introduction'
                },
                description: {
                  ar: 'نظرة عامة على محتوى الدورة وأهدافها',
                  en: 'Overview of course content and objectives'
                },
                fileUrl: 'https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4',
                duration: 10
              },
              {
                _id: 'c2',
                type: 'pdf',
                title: {
                  ar: 'ملخص المفاهيم الأساسية',
                  en: 'Summary of Basic Concepts'
                },
                description: {
                  ar: 'ملخص للمفاهيم الأساسية في إدارة المبيعات',
                  en: 'Summary of basic concepts in sales management'
                },
                fileUrl: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf',
              }
            ]
          },
          {
            _id: 'm2',
            title: {
              ar: 'استراتيجيات البيع',
              en: 'Sales Strategies'
            },
            description: {
              ar: 'تطوير وتنفيذ استراتيجيات البيع الفعالة',
              en: 'Developing and implementing effective sales strategies'
            },
            order: 2,
            content: [
              {
                _id: 'c3',
                type: 'video',
                title: {
                  ar: 'أنواع استراتيجيات البيع',
                  en: 'Types of Sales Strategies'
                },
                description: {
                  ar: 'شرح لأنواع استراتيجيات البيع المختلفة',
                  en: 'Explanation of different types of sales strategies'
                },
                fileUrl: 'https://sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4',
                duration: 15
              },
              {
                _id: 'c4',
                type: 'quiz',
                title: {
                  ar: 'اختبار استراتيجيات البيع',
                  en: 'Sales Strategies Quiz'
                },
                description: {
                  ar: 'اختبار لقياس فهم استراتيجيات البيع',
                  en: 'Quiz to measure understanding of sales strategies'
                },
                quizId: 'q1'
              }
            ]
          }
        ]);
        
        setStudentProgress({
          userId: userInfo._id,
          courseId: courseId,
          completedContent: [
            {
              moduleId: 'm1',
              contentIndex: 0,
              completedAt: new Date().toISOString()
            }
          ],
          quizResults: [],
          overallProgress: 25,
          lastAccessedAt: new Date().toISOString(),
          certificateIssued: false
        });
        
        setLoading(false);
      }, 1000);
    }
  }, [dispatch, navigate, userInfo, courseId]);

  // تحديث المحتوى النشط عند تغيير الوحدة أو المحتوى المحدد
  useEffect(() => {
    if (modules.length > 0 && modules[selectedModuleIndex] && modules[selectedModuleIndex].content.length > 0) {
      setActiveContent(modules[selectedModuleIndex].content[selectedContentIndex]);
    }
  }, [modules, selectedModuleIndex, selectedContentIndex]);

  // التحقق من اكتمال المحتوى
  const isContentCompleted = (moduleId, contentIndex) => {
    if (!studentProgress) return false;
    
    return studentProgress.completedContent.some(
      item => item.moduleId === moduleId && item.contentIndex === contentIndex
    );
  };

  // تحديد نوع المحتوى النشط
  const getContentIcon = (type) => {
    switch (type) {
      case 'video':
        return <VideoIcon />;
      case 'pdf':
        return <PdfIcon />;
      case 'quiz':
        return <QuizIcon />;
      default:
        return null;
    }
  };

  // ترجمة نوع المحتوى
  const translateContentType = (type) => {
    switch (type) {
      case 'video':
        return 'فيديو';
      case 'pdf':
        return 'ملف PDF';
      case 'quiz':
        return 'اختبار';
      default:
        return type;
    }
  };

  // تغيير الوحدة المحددة
  const handleModuleChange = (index) => {
    setSelectedModuleIndex(index);
    setSelectedContentIndex(0);
  };

  // تغيير المحتوى المحدد
  const handleContentChange = (index) => {
    setSelectedContentIndex(index);
  };

  // تحديد المحتوى كمكتمل
  const handleMarkAsCompleted = () => {
    if (!activeContent) return;
    
    const moduleId = modules[selectedModuleIndex]._id;
    dispatch(markContentAsCompleted(courseId, moduleId, selectedContentIndex));
    
    // محاكاة تحديث التقدم (سيتم استبداله بالمنطق الفعلي)
    const updatedProgress = {
      ...studentProgress,
      completedContent: [
        ...studentProgress.completedContent,
        {
          moduleId,
          contentIndex: selectedContentIndex,
          completedAt: new Date().toISOString()
        }
      ]
    };
    
    // حساب التقدم الإجمالي
    const totalContentCount = modules.reduce((sum, module) => sum + module.content.length, 0);
    updatedProgress.overallProgress = (updatedProgress.completedContent.length / totalContentCount) * 100;
    
    setStudentProgress(updatedProgress);
  };

  // عرض مشغل الفيديو
  const renderVideoPlayer = () => {
    if (!activeContent || activeContent.type !== 'video') return null;
    
    return (
      <Box sx={{ width: '100%', mb: 3 }}>
        <video
          controls
          width="100%"
          poster={course.thumbnail}
          style={{ borderRadius: '8px' }}
        >
          <source src={activeContent.fileUrl} type="video/mp4" />
          متصفحك لا يدعم تشغيل الفيديو.
        </video>
      </Box>
    );
  };

  // عرض عارض PDF
  const renderPdfViewer = () => {
    if (!activeContent || activeContent.type !== 'pdf') return null;
    
    return (
      <Box sx={{ width: '100%', mb: 3 }}>
        <iframe
          src={`${activeContent.fileUrl}#toolbar=0&navpanes=0`}
          width="100%"
          height="600px"
          style={{ border: 'none', borderRadius: '8px' }}
          title={activeContent.title.ar}
        />
      </Box>
    );
  };

  // عرض الاختبار
  const renderQuiz = () => {
    if (!activeContent || activeContent.type !== 'quiz') return null;
    
    return (
      <Box sx={{ width: '100%', mb: 3 }}>
        <Card variant="outlined" sx={{ mb: 3 }}>
          <CardContent>
            <Typography variant="h6" sx={{ mb: 2 }}>
              {activeContent.title.ar}
            </Typography>
            <Typography variant="body2" sx={{ mb: 3 }}>
              {activeContent.description.ar}
            </Typography>
            <Button
              variant="contained"
              color="primary"
              onClick={() => navigate(`/quiz/${activeContent.quizId}`)}
            >
              بدء الاختبار
            </Button>
          </CardContent>
        </Card>
      </Box>
    );
  };

  return (
    <Container component="main" maxWidth="lg" dir="rtl">
      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
          <CircularProgress />
        </Box>
      ) : course ? (
        <Grid container spacing={3} sx={{ mt: 2 }}>
          {/* قائمة الوحدات والمحتوى */}
          <Grid item xs={12} md={4}>
            <Paper elevation={3} sx={{ p: 2, mb: 3 }}>
              <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold' }}>
                محتويات الدورة
              </Typography>
              
              {studentProgress && (
                <Box sx={{ mb: 3 }}>
                  <Typography variant="body2" sx={{ mb: 1 }}>
                    تقدمك في الدورة: {Math.round(studentProgress.overallProgress)}%
                  </Typography>
                  <LinearProgress 
                    variant="determinate" 
                    value={studentProgress.overallProgress} 
                    sx={{ height: 8, borderRadius: 4 }}
                  />
                </Box>
              )}
              
              <List component="nav" sx={{ width: '100%', bgcolor: 'background.paper' }}>
                {modules.map((module, moduleIndex) => (
                  <React.Fragment key={module._id}>
                    <ListItem 
                      button 
                      onClick={() => handleModuleChange(moduleIndex)}
                      selected={selectedModuleIndex === moduleIndex}
                      sx={{ bgcolor: selectedModuleIndex === moduleIndex ? 'action.selected' : 'inherit' }}
                    >
                      <ListItemText 
                        primary={`${module.order}. ${module.title.ar}`} 
                        primaryTypographyProps={{ fontWeight: 'bold' }}
                      />
                    </ListItem>
                    
                    {selectedModuleIndex === moduleIndex && (
                      <List component="div" disablePadding>
                        {module.content.map((content, contentIndex) => (
                          <ListItem 
                            key={content._id}
                            button 
                            onClick={() => handleContentChange(contentIndex)}
                            selected={selectedModuleIndex === moduleIndex && selectedContentIndex === contentIndex}
                            sx={{ pl: 4 }}
                          >
                            <ListItemIcon>
                              {getContentIcon(content.type)}
                            </ListItemIcon>
                            <ListItemText 
                              primary={content.title.ar} 
                              secondary={translateContentType(content.type)}
                            />
                            <ListItemIcon>
                              {isContentCompleted(module._id, contentIndex) ? (
                                <CompletedIcon color="success" />
                              ) : (
                                <IncompleteIcon />
                              )}
                            </ListItemIcon>
                          </ListItem>
                        ))}
                      </List>
                    )}
                    
                    <Divider component="li" />
                  </React.Fragment>
                ))}
              </List>
            </Paper>
          </Grid>
          
          {/* عرض المحتوى */}
          <Grid item xs={12} md={8}>
            <Paper elevation={3} sx={{ p: 3 }}>
              {activeContent ? (
                <>
                  <Typography variant="h5" sx={{ mb: 1, fontWeight: 'bold' }}>
                    {activeContent.title.ar}
                  </Typography>
                  
                  <Typography variant="body1" color="text.secondary" sx={{ mb: 3 }}>
                    {activeContent.description.ar}
                  </Typography>
                  
                  <Divider sx={{ mb: 3 }} />
                  
                  {/* عرض المحتوى حسب النوع */}
                  {activeContent.type === 'video' && renderVideoPlayer()}
                  {activeContent.type === 'pdf' && renderPdfViewer()}
                  {activeContent.type === 'quiz' && renderQuiz()}
                  
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 3 }}>
                    <Button
                      variant="outlined"
                      disabled={selectedContentIndex === 0 && selectedModuleIndex === 0}
                      onClick={() => {
                        if (selectedContentIndex > 0) {
                          setSelectedContentIndex(selectedContentIndex - 1);
                        } else if (selectedModuleIndex > 0) {
                          setSelectedModuleIndex(selectedModuleIndex - 1);
                          setSelectedContentIndex(modules[selectedModuleIndex - 1].content.length - 1);
                        }
                      }}
                    >
                      السابق
                    </Button>
                    
                    <Button
                      variant="contained"
                      color="success"
                      disabled={isContentCompleted(modules[selectedModuleIndex]._id, selectedContentIndex)}
                      onClick={handleMarkAsCompleted}
                    >
                      تحديد كمكتمل
                    </Button>
                    
                    <Button
                      variant="outlined"
                      disabled={
                        selectedModuleIndex === modules.length - 1 && 
                        selectedContentIndex === modules[selectedModuleIndex].content.length - 1
                      }
                      onClick={() => {
                        if (selectedContentIndex < modules[selectedModuleIndex].content.length - 1) {
                          setSelectedContentIndex(selectedContentIndex + 1);
                        } else if (selectedModuleIndex < modules.length - 1) {
                          setSelectedModuleIndex(selectedModuleIndex + 1);
                          setSelectedContentIndex(0);
                        }
                      }}
                    >
                      التالي
                    </Button>
                  </Box>
                </>
              ) : (
                <Alert severity="info">
                  يرجى اختيار محتوى من القائمة للبدء في التعلم.
                </Alert>
              )}
            </Paper>
          </Grid>
        </Grid>
      ) : (
        <Alert severity="error" sx={{ mt: 4 }}>
          لم يتم العثور على الدورة أو أنك غير مسجل فيها.
        </Alert>
      )}
    </Container>
  );
};

export default StudentCourseScreen;
