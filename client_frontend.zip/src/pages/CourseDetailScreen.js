import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  TextField,
  Button,
  Typography,
  Box,
  Container,
  Paper,
  CircularProgress,
  Alert,
  Grid,
  Tabs,
  Tab,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  IconButton,
  Divider,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  FormControl,
  InputLabel,
  Select,
  MenuItem
} from '@mui/material';
import { 
  Add as AddIcon, 
  Edit as EditIcon, 
  Delete as DeleteIcon,
  ArrowUpward as ArrowUpwardIcon,
  ArrowDownward as ArrowDownwardIcon
} from '@mui/icons-material';
import { useNavigate, useParams } from 'react-router-dom';

// سيتم استبدال هذا بإجراءات Redux الفعلية
const getCourseDetails = (id) => ({ type: 'GET_COURSE_DETAILS_REQUEST', payload: id });
const createModule = (moduleData) => ({ type: 'CREATE_MODULE_REQUEST', payload: moduleData });
const deleteModule = (id) => ({ type: 'DELETE_MODULE_REQUEST', payload: id });
const addContent = (moduleId, contentData) => ({ type: 'ADD_CONTENT_REQUEST', payload: { moduleId, contentData } });
const deleteContent = (moduleId, contentIndex) => ({ type: 'DELETE_CONTENT_REQUEST', payload: { moduleId, contentIndex } });

const CourseDetailScreen = () => {
  const { id: courseId } = useParams();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  
  // سيتم استبدال هذا بحالة Redux الفعلية
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [course, setCourse] = useState(null);
  const [modules, setModules] = useState([]);
  
  const userLogin = useSelector((state) => state.userLogin);
  const { userInfo } = userLogin;

  // حالة الواجهة
  const [tabValue, setTabValue] = useState(0);
  const [openModuleDialog, setOpenModuleDialog] = useState(false);
  const [openContentDialog, setOpenContentDialog] = useState(false);
  const [selectedModule, setSelectedModule] = useState(null);
  const [moduleData, setModuleData] = useState({
    title: { ar: '', en: '' },
    description: { ar: '', en: '' },
    order: 0
  });
  const [contentData, setContentData] = useState({
    type: 'video',
    title: { ar: '', en: '' },
    description: { ar: '', en: '' },
    fileUrl: '',
    duration: 0
  });

  // التحقق من صلاحيات المستخدم وتحميل تفاصيل الدورة
  useEffect(() => {
    if (!userInfo) {
      navigate('/login');
    } else {
      dispatch(getCourseDetails(courseId));
      
      // محاكاة تحميل البيانات (سيتم استبداله بالمنطق الفعلي)
      setLoading(true);
      setTimeout(() => {
        setCourse({
          _id: courseId,
          title: {
            ar: 'مبادئ إدارة المبيعات',
            en: 'Sales Management Principles'
          },
          description: {
            ar: 'دورة شاملة في أساسيات إدارة المبيعات وتطوير استراتيجيات البيع',
            en: 'Comprehensive course in sales management fundamentals and strategy development'
          },
          instructor: {
            _id: '1',
            fullName: 'صادق زيدان'
          },
          thumbnail: 'https://via.placeholder.com/300x200?text=Sales+Management',
          isPublished: true,
          enrolledStudents: ['101', '102', '103'],
        });
        
        setModules([
          {
            _id: 'm1',
            title: {
              ar: 'مقدمة في إدارة المبيعات',
              en: 'Introduction to Sales Management'
            },
            description: {
              ar: 'نظرة عامة على مفاهيم إدارة المبيعات',
              en: 'Overview of sales management concepts'
            },
            order: 1,
            content: [
              {
                _id: 'c1',
                type: 'video',
                title: {
                  ar: 'مقدمة الدورة',
                  en: 'Course Introduction'
                },
                description: {
                  ar: 'نظرة عامة على محتوى الدورة وأهدافها',
                  en: 'Overview of course content and objectives'
                },
                fileUrl: 'https://example.com/videos/intro.mp4',
                duration: 10
              },
              {
                _id: 'c2',
                type: 'pdf',
                title: {
                  ar: 'ملخص المفاهيم الأساسية',
                  en: 'Summary of Basic Concepts'
                },
                description: {
                  ar: 'ملخص للمفاهيم الأساسية في إدارة المبيعات',
                  en: 'Summary of basic concepts in sales management'
                },
                fileUrl: 'https://example.com/pdfs/concepts.pdf',
              }
            ]
          },
          {
            _id: 'm2',
            title: {
              ar: 'استراتيجيات البيع',
              en: 'Sales Strategies'
            },
            description: {
              ar: 'تطوير وتنفيذ استراتيجيات البيع الفعالة',
              en: 'Developing and implementing effective sales strategies'
            },
            order: 2,
            content: [
              {
                _id: 'c3',
                type: 'video',
                title: {
                  ar: 'أنواع استراتيجيات البيع',
                  en: 'Types of Sales Strategies'
                },
                description: {
                  ar: 'شرح لأنواع استراتيجيات البيع المختلفة',
                  en: 'Explanation of different types of sales strategies'
                },
                fileUrl: 'https://example.com/videos/strategies.mp4',
                duration: 15
              },
              {
                _id: 'c4',
                type: 'quiz',
                title: {
                  ar: 'اختبار استراتيجيات البيع',
                  en: 'Sales Strategies Quiz'
                },
                description: {
                  ar: 'اختبار لقياس فهم استراتيجيات البيع',
                  en: 'Quiz to measure understanding of sales strategies'
                },
                quizId: 'q1'
              }
            ]
          }
        ]);
        setLoading(false);
      }, 1000);
    }
  }, [dispatch, navigate, userInfo, courseId]);

  // تغيير التبويب
  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  // فتح مربع حوار إضافة وحدة
  const handleOpenModuleDialog = () => {
    setModuleData({
      title: { ar: '', en: '' },
      description: { ar: '', en: '' },
      order: modules.length + 1
    });
    setOpenModuleDialog(true);
  };

  // فتح مربع حوار إضافة محتوى
  const handleOpenContentDialog = (moduleId) => {
    setSelectedModule(moduleId);
    setContentData({
      type: 'video',
      title: { ar: '', en: '' },
      description: { ar: '', en: '' },
      fileUrl: '',
      duration: 0
    });
    setOpenContentDialog(true);
  };

  // تحديث بيانات الوحدة
  const handleModuleChange = (e, language = null, field = null) => {
    if (language && field) {
      setModuleData({
        ...moduleData,
        [field]: {
          ...moduleData[field],
          [language]: e.target.value
        }
      });
    } else {
      setModuleData({
        ...moduleData,
        [e.target.name]: e.target.value
      });
    }
  };

  // تحديث بيانات المحتوى
  const handleContentChange = (e, language = null, field = null) => {
    if (language && field) {
      setContentData({
        ...contentData,
        [field]: {
          ...contentData[field],
          [language]: e.target.value
        }
      });
    } else {
      setContentData({
        ...contentData,
        [e.target.name]: e.target.value
      });
    }
  };

  // إضافة وحدة جديدة
  const handleAddModule = () => {
    if (!moduleData.title.ar || !moduleData.title.en) {
      setError('يجب توفير عنوان الوحدة باللغتين العربية والإنجليزية');
      return;
    }
    
    dispatch(createModule({ ...moduleData, courseId }));
    
    // محاكاة الإضافة (سيتم استبداله بالمنطق الفعلي)
    const newModule = {
      _id: `m${Date.now()}`,
      ...moduleData,
      content: []
    };
    setModules([...modules, newModule]);
    setOpenModuleDialog(false);
  };

  // إضافة محتوى جديد
  const handleAddContent = () => {
    if (!contentData.title.ar || !contentData.title.en) {
      setError('يجب توفير عنوان المحتوى باللغتين العربية والإنجليزية');
      return;
    }
    
    dispatch(addContent(selectedModule, contentData));
    
    // محاكاة الإضافة (سيتم استبداله بالمنطق الفعلي)
    const updatedModules = modules.map(module => {
      if (module._id === selectedModule) {
        return {
          ...module,
          content: [...module.content, {
            _id: `c${Date.now()}`,
            ...contentData
          }]
        };
      }
      return module;
    });
    setModules(updatedModules);
    setOpenContentDialog(false);
  };

  // حذف وحدة
  const handleDeleteModule = (moduleId) => {
    if (window.confirm('هل أنت متأكد من حذف هذه الوحدة؟')) {
      dispatch(deleteModule(moduleId));
      
      // محاكاة الحذف (سيتم استبداله بالمنطق الفعلي)
      setModules(modules.filter(module => module._id !== moduleId));
    }
  };

  // حذف محتوى
  const handleDeleteContent = (moduleId, contentIndex) => {
    if (window.confirm('هل أنت متأكد من حذف هذا المحتوى؟')) {
      dispatch(deleteContent(moduleId, contentIndex));
      
      // محاكاة الحذف (سيتم استبداله بالمنطق الفعلي)
      const updatedModules = modules.map(module => {
        if (module._id === moduleId) {
          return {
            ...module,
            content: module.content.filter((_, index) => index !== contentIndex)
          };
        }
        return module;
      });
      setModules(updatedModules);
    }
  };

  // تغيير ترتيب الوحدة
  const handleModuleOrderChange = (moduleId, direction) => {
    const moduleIndex = modules.findIndex(m => m._id === moduleId);
    if ((direction === 'up' && moduleIndex === 0) || 
        (direction === 'down' && moduleIndex === modules.length - 1)) {
      return;
    }
    
    const newModules = [...modules];
    const targetIndex = direction === 'up' ? moduleIndex - 1 : moduleIndex + 1;
    
    // تبديل الوحدات
    [newModules[moduleIndex], newModules[targetIndex]] = [newModules[targetIndex], newModules[moduleIndex]];
    
    // تحديث الترتيب
    newModules[moduleIndex].order = moduleIndex + 1;
    newModules[targetIndex].order = targetIndex + 1;
    
    setModules(newModules);
  };

  // ترجمة نوع المحتوى
  const translateContentType = (type) => {
    switch (type) {
      case 'video':
        return 'فيديو';
      case 'pdf':
        return 'ملف PDF';
      case 'quiz':
        return 'اختبار';
      default:
        return type;
    }
  };

  return (
    <Container component="main" maxWidth="lg" dir="rtl">
      <Paper
        elevation={3}
        sx={{
          marginTop: 4,
          marginBottom: 4,
          padding: 4,
        }}
      >
        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
            <CircularProgress />
          </Box>
        ) : course ? (
          <>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
              <Typography component="h1" variant="h5" sx={{ fontWeight: 'bold' }}>
                {course.title.ar}
              </Typography>
              <Button
                variant="outlined"
                color="primary"
                onClick={() => navigate(`/course/${courseId}/edit`)}
              >
                تعديل معلومات الدورة
              </Button>
            </Box>

            {error && <Alert severity="error" sx={{ width: '100%', mb: 2 }}>{error}</Alert>}

            <Box sx={{ mb: 4 }}>
              <Typography variant="body1" sx={{ mb: 2 }}>
                {course.description.ar}
              </Typography>
              <Grid container spacing={2}>
                <Grid item xs={12} sm={6}>
                  <Typography variant="body2" color="text.secondary">
                    المدرب: {course.instructor.fullName}
                  </Typography>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <Typography variant="body2" color="text.secondary">
                    عدد الطلاب المسجلين: {course.enrolledStudents.length}
                  </Typography>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <Typography variant="body2" color="text.secondary">
                    الحالة: {course.isPublished ? 'منشورة' : 'مسودة'}
                  </Typography>
                </Grid>
              </Grid>
            </Box>

            <Divider sx={{ mb: 3 }} />

            <Box sx={{ width: '100%' }}>
              <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 2 }}>
                <Tabs value={tabValue} onChange={handleTabChange} aria-label="course tabs">
                  <Tab label="وحدات الدورة" />
                  <Tab label="الطلاب المسجلين" />
                </Tabs>
              </Box>

              {/* تبويب وحدات الدورة */}
              {tabValue === 0 && (
                <Box>
                  <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 2 }}>
                    <Button
                      variant="contained"
                      color="primary"
                      startIcon={<AddIcon />}
                      onClick={handleOpenModuleDialog}
                    >
                      إضافة وحدة جديدة
                    </Button>
                  </Box>

                  {modules.length === 0 ? (
                    <Alert severity="info">لا توجد وحدات في هذه الدورة. أضف وحدة جديدة للبدء.</Alert>
                  ) : (
                    modules.map((module, index) => (
                      <Paper key={module._id} elevation={2} sx={{ mb: 3, p: 2 }}>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                          <Typography variant="h6">
                            {module.order}. {module.title.ar}
                          </Typography>
                          <Box>
                            <IconButton 
                              color="primary" 
                              onClick={() => handleModuleOrderChange(module._id, 'up')}
                              disabled={index === 0}
                            >
                              <ArrowUpwardIcon />
                            </IconButton>
                            <IconButton 
                              color="primary" 
                              onClick={() => handleModuleOrderChange(module._id, 'down')}
                              disabled={index === modules.length - 1}
                            >
                              <ArrowDownwardIcon />
                            </IconButton>
                            <IconButton 
                              color="primary" 
                              onClick={() => navigate(`/module/${module._id}/edit`)}
                            >
                              <EditIcon />
                            </IconButton>
                            <IconButton 
                              color="error" 
                              onClick={() => handleDeleteModule(module._id)}
                            >
                              <DeleteIcon />
                            </IconButton>
                          </Box>
                        </Box>

                        <Typography variant="body2" sx={{ mb: 2 }}>
                          {module.description.ar}
                        </Typography>

                        <Divider sx={{ mb: 2 }} />

                        <Typography variant="subtitle1" sx={{ mb: 1 }}>
                          محتوى الوحدة:
                        </Typography>

                        {module.content.length === 0 ? (
                          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                            لا يوجد محتوى في هذه الوحدة.
                          </Typography>
                        ) : (
                          <List dense>
                            {module.content.map((content, contentIndex) => (
                              <ListItem key={content._id}>
                                <ListItemText
                                  primary={`${contentIndex + 1}. ${content.title.ar}`}
                                  secondary={`${translateContentType(content.type)} - ${content.description.ar}`}
                                />
                                <ListItemSecondaryAction>
                                  <IconButton 
                                    edge="end" 
                                    aria-label="edit"
                                    onClick={() => navigate(`/module/${module._id}/content/${contentIndex}/edit`)}
                                  >
                                    <EditIcon />
                                  </IconButton>
                                  <IconButton 
                                    edge="end" 
                                    aria-label="delete"
                                    onClick={() => handleDeleteContent(module._id, contentIndex)}
                                  >
                                    <DeleteIcon />
                                  </IconButton>
                                </ListItemSecondaryAction>
                              </ListItem>
                            ))}
                          </List>
                        )}

                        <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 2 }}>
                          <Button
                            variant="outlined"
                            size="small"
                            startIcon={<AddIcon />}
                            onClick={() => handleOpenContentDialog(module._id)}
                          >
                            إضافة محتوى
                          </Button>
                        </Box>
                      </Paper>
                    ))
                  )}
                </Box>
              )}

              {/* تبويب الطلاب المسجلين */}
              {tabValue === 1 && (
                <Box>
                  <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 2 }}>
                    <Button
                      variant="contained"
                      color="primary"
                      startIcon={<AddIcon />}
                      onClick={() => navigate(`/course/${courseId}/enroll`)}
                    >
                      تسجيل طالب جديد
                    </Button>
                  </Box>

                  {course.enrolledStudents.length === 0 ? (
                    <Alert severity="info">لا يوجد طلاب مسجلين في هذه الدورة.</Alert>
                  ) : (
                    <Typography variant="body1">
                      عدد الطلاب المسجلين: {course.enrolledStudents.length}
                    </Typography>
                    // هنا سيتم عرض قائمة الطلاب المسجلين
                  )}
                </Box>
              )}
            </Box>
          </>
        ) : (
          <Alert severity="error">لم يتم العثور على الدورة</Alert>
        )}
      </Paper>

      {/* مربع حوار إضافة وحدة جديدة */}
      <Dialog open={openModuleDialog} onClose={() => setOpenModuleDialog(false)} maxWidth="md" fullWidth>
        <DialogTitle>إضافة وحدة جديدة</DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12}>
              <TextField
                required
                fullWidth
                label="عنوان الوحدة (بالعربية)"
                value={moduleData.title.ar}
                onChange={(e) => handleModuleChange(e, 'ar', 'title')}
                sx={{ mb: 2 }}
              />
            </Grid>
            
            <Grid item xs={12}>
              <TextField
                required
                fullWidth
                label="عنوان الوحدة (بالإنجليزية)"
                value={moduleData.title.en}
                onChange={(e) => handleModuleChange(e, 'en', 'title')}
                sx={{ mb: 2 }}
              />
            </Grid>
            
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="وصف الوحدة (بالعربية)"
                multiline
                rows={2}
                value={moduleData.description.ar}
                onChange={(e) => handleModuleChange(e, 'ar', 'description')}
                sx={{ mb: 2 }}
              />
            </Grid>
            
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="وصف الوحدة (بالإنجليزية)"
                multiline
                rows={2}
                value={moduleData.description.en}
                onChange={(e) => handleModuleChange(e, 'en', 'description')}
                sx={{ mb: 2 }}
              />
            </Grid>
            
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="الترتيب"
                type="number"
                name="order"
                value={moduleData.order}
                onChange={handleModuleChange}
                sx={{ mb: 2 }}
              />
            </Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenModuleDialog(false)} color="secondary">
            إلغاء
          </Button>
          <Button onClick={handleAddModule} color="primary">
            إضافة
          </Button>
        </DialogActions>
      </Dialog>

      {/* مربع حوار إضافة محتوى جديد */}
      <Dialog open={openContentDialog} onClose={() => setOpenContentDialog(false)} maxWidth="md" fullWidth>
        <DialogTitle>إضافة محتوى جديد</DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12}>
              <FormControl fullWidth sx={{ mb: 2 }}>
                <InputLabel id="content-type-label">نوع المحتوى</InputLabel>
                <Select
                  labelId="content-type-label"
                  name="type"
                  value={contentData.type}
                  label="نوع المحتوى"
                  onChange={handleContentChange}
                >
                  <MenuItem value="video">فيديو</MenuItem>
                  <MenuItem value="pdf">ملف PDF</MenuItem>
                  <MenuItem value="quiz">اختبار</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            
            <Grid item xs={12}>
              <TextField
                required
                fullWidth
                label="عنوان المحتوى (بالعربية)"
                value={contentData.title.ar}
                onChange={(e) => handleContentChange(e, 'ar', 'title')}
                sx={{ mb: 2 }}
              />
            </Grid>
            
            <Grid item xs={12}>
              <TextField
                required
                fullWidth
                label="عنوان المحتوى (بالإنجليزية)"
                value={contentData.title.en}
                onChange={(e) => handleContentChange(e, 'en', 'title')}
                sx={{ mb: 2 }}
              />
            </Grid>
            
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="وصف المحتوى (بالعربية)"
                multiline
                rows={2}
                value={contentData.description.ar}
                onChange={(e) => handleContentChange(e, 'ar', 'description')}
                sx={{ mb: 2 }}
              />
            </Grid>
            
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="وصف المحتوى (بالإنجليزية)"
                multiline
                rows={2}
                value={contentData.description.en}
                onChange={(e) => handleContentChange(e, 'en', 'description')}
                sx={{ mb: 2 }}
              />
            </Grid>
            
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="رابط الملف"
                name="fileUrl"
                value={contentData.fileUrl}
                onChange={handleContentChange}
                sx={{ mb: 2 }}
              />
            </Grid>
            
            {contentData.type === 'video' && (
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="المدة (بالدقائق)"
                  type="number"
                  name="duration"
                  value={contentData.duration}
                  onChange={handleContentChange}
                  sx={{ mb: 2 }}
                />
              </Grid>
            )}
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenContentDialog(false)} color="secondary">
            إلغاء
          </Button>
          <Button onClick={handleAddContent} color="primary">
            إضافة
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
};

export default CourseDetailScreen;
