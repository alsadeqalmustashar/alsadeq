import React, { useState, useEffect, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Box,
  Container,
  Paper,
  Typography,
  CircularProgress,
  Alert,
  Grid,
  Card,
  CardContent,
  TextField,
  Button,
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  Avatar,
  Divider,
  IconButton,
  Tabs,
  Tab,
  Badge
} from '@mui/material';
import {
  Send as SendIcon,
  Mic as MicIcon,
  MicOff as MicOffIcon,
  Videocam as VideocamIcon,
  VideocamOff as VideocamOffIcon,
  ScreenShare as ScreenShareIcon,
  StopScreenShare as StopScreenShareIcon,
  Chat as ChatIcon,
  People as PeopleIcon,
  Close as CloseIcon
} from '@mui/icons-material';

// سيتم استبدال هذا بإجراءات Redux الفعلية
const getLiveSessionDetails = (id) => ({ type: 'GET_LIVE_SESSION_DETAILS_REQUEST', payload: id });
const sendChatMessage = (sessionId, message) => ({ 
  type: 'SEND_CHAT_MESSAGE_REQUEST', 
  payload: { sessionId, message } 
});
const joinLiveSession = (sessionId) => ({ type: 'JOIN_LIVE_SESSION_REQUEST', payload: sessionId });
const leaveLiveSession = (sessionId) => ({ type: 'LEAVE_LIVE_SESSION_REQUEST', payload: sessionId });

const LiveSessionScreen = () => {
  const { id: sessionId } = useParams();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  
  // سيتم استبدال هذا بحالة Redux الفعلية
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [session, setSession] = useState(null);
  const [messages, setMessages] = useState([]);
  const [participants, setParticipants] = useState([]);
  
  const userLogin = useSelector((state) => state.userLogin);
  const { userInfo } = userLogin;

  // حالة الواجهة
  const [message, setMessage] = useState('');
  const [tabValue, setTabValue] = useState(0);
  const [isJoined, setIsJoined] = useState(false);
  const [isMicEnabled, setIsMicEnabled] = useState(false);
  const [isCameraEnabled, setIsCameraEnabled] = useState(false);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [unreadMessages, setUnreadMessages] = useState(0);
  
  // مراجع للعناصر
  const localVideoRef = useRef(null);
  const remoteVideoRef = useRef(null);
  const chatListRef = useRef(null);
  
  // محاكاة اتصال WebSocket
  const [socket, setSocket] = useState(null);

  // التحقق من صلاحيات المستخدم وتحميل تفاصيل الجلسة المباشرة
  useEffect(() => {
    if (!userInfo) {
      navigate('/login');
    } else {
      dispatch(getLiveSessionDetails(sessionId));
      
      // محاكاة تحميل البيانات (سيتم استبداله بالمنطق الفعلي)
      setLoading(true);
      setTimeout(() => {
        const mockSession = {
          _id: sessionId,
          title: {
            ar: 'استراتيجيات المبيعات المتقدمة - جلسة مباشرة',
            en: 'Advanced Sales Strategies - Live Session'
          },
          description: {
            ar: 'جلسة تفاعلية لمناقشة استراتيجيات المبيعات المتقدمة وتطبيقاتها',
            en: 'Interactive session to discuss advanced sales strategies and their applications'
          },
          instructor: {
            _id: '1',
            fullName: 'صادق زيدان',
            avatar: 'https://via.placeholder.com/150'
          },
          courseId: 'c1',
          courseName: {
            ar: 'مبادئ إدارة المبيعات',
            en: 'Sales Management Principles'
          },
          startTime: new Date(Date.now() - 10 * 60 * 1000).toISOString(), // بدأت قبل 10 دقائق
          endTime: new Date(Date.now() + 50 * 60 * 1000).toISOString(), // تنتهي بعد 50 دقيقة
          status: 'active',
          recordingEnabled: true
        };
        
        const mockParticipants = [
          {
            _id: '1',
            fullName: 'صادق زيدان',
            role: 'instructor',
            avatar: 'https://via.placeholder.com/150',
            isActive: true,
            joinedAt: new Date(Date.now() - 10 * 60 * 1000).toISOString()
          },
          {
            _id: '101',
            fullName: 'أحمد محمد',
            role: 'student',
            avatar: 'https://via.placeholder.com/150',
            isActive: true,
            joinedAt: new Date(Date.now() - 8 * 60 * 1000).toISOString()
          },
          {
            _id: '102',
            fullName: 'سارة علي',
            role: 'student',
            avatar: 'https://via.placeholder.com/150',
            isActive: true,
            joinedAt: new Date(Date.now() - 5 * 60 * 1000).toISOString()
          },
          {
            _id: '103',
            fullName: 'محمد خالد',
            role: 'student',
            avatar: 'https://via.placeholder.com/150',
            isActive: false,
            joinedAt: new Date(Date.now() - 7 * 60 * 1000).toISOString(),
            leftAt: new Date(Date.now() - 2 * 60 * 1000).toISOString()
          }
        ];
        
        const mockMessages = [
          {
            _id: 'm1',
            sender: {
              _id: '1',
              fullName: 'صادق زيدان',
              role: 'instructor',
              avatar: 'https://via.placeholder.com/150'
            },
            text: 'مرحباً بكم جميعاً في هذه الجلسة المباشرة حول استراتيجيات المبيعات المتقدمة.',
            timestamp: new Date(Date.now() - 9 * 60 * 1000).toISOString()
          },
          {
            _id: 'm2',
            sender: {
              _id: '101',
              fullName: 'أحمد محمد',
              role: 'student',
              avatar: 'https://via.placeholder.com/150'
            },
            text: 'شكراً لك أستاذ صادق، متحمس للجلسة.',
            timestamp: new Date(Date.now() - 8.5 * 60 * 1000).toISOString()
          },
          {
            _id: 'm3',
            sender: {
              _id: '1',
              fullName: 'صادق زيدان',
              role: 'instructor',
              avatar: 'https://via.placeholder.com/150'
            },
            text: 'سنبدأ بمناقشة أهم استراتيجيات المبيعات للمنتجات ذات القيمة العالية.',
            timestamp: new Date(Date.now() - 7 * 60 * 1000).toISOString()
          },
          {
            _id: 'm4',
            sender: {
              _id: '102',
              fullName: 'سارة علي',
              role: 'student',
              avatar: 'https://via.placeholder.com/150'
            },
            text: 'هل يمكن أن تشرح لنا كيفية تطبيق استراتيجية البيع الاستشاري في سوق التكنولوجيا؟',
            timestamp: new Date(Date.now() - 5 * 60 * 1000).toISOString()
          },
          {
            _id: 'm5',
            sender: {
              _id: '1',
              fullName: 'صادق زيدان',
              role: 'instructor',
              avatar: 'https://via.placeholder.com/150'
            },
            text: 'بالتأكيد سارة، سأشرح ذلك بالتفصيل خلال العرض. استراتيجية البيع الاستشاري تعتمد على فهم احتياجات العميل أولاً ثم تقديم الحلول المناسبة.',
            timestamp: new Date(Date.now() - 4 * 60 * 1000).toISOString()
          }
        ];
        
        setSession(mockSession);
        setParticipants(mockParticipants);
        setMessages(mockMessages);
        setLoading(false);
        
        // محاكاة اتصال WebSocket
        const mockSocket = {
          connected: true,
          on: (event, callback) => {
            console.log(`Socket listening to ${event}`);
            // محاكاة استلام رسائل جديدة
            if (event === 'new_message') {
              const intervalId = setInterval(() => {
                if (Math.random() > 0.7) {
                  const newMessage = {
                    _id: `m${Date.now()}`,
                    sender: mockParticipants[Math.floor(Math.random() * mockParticipants.length)],
                    text: `رسالة تجريبية في الوقت ${new Date().toLocaleTimeString()}`,
                    timestamp: new Date().toISOString()
                  };
                  callback(newMessage);
                }
              }, 15000);
              
              return () => clearInterval(intervalId);
            }
          },
          emit: (event, data) => {
            console.log(`Socket emitting ${event}`, data);
            return true;
          },
          disconnect: () => {
            console.log('Socket disconnected');
            return true;
          }
        };
        
        setSocket(mockSocket);
      }, 1000);
    }
  }, [dispatch, navigate, userInfo, sessionId]);

  // محاكاة استلام رسائل جديدة
  useEffect(() => {
    if (socket) {
      const handleNewMessage = (newMessage) => {
        setMessages(prevMessages => [...prevMessages, newMessage]);
        
        // زيادة عدد الرسائل غير المقروءة إذا كانت علامة التبويب الحالية ليست الدردشة
        if (tabValue !== 0) {
          setUnreadMessages(prev => prev + 1);
        }
      };
      
      socket.on('new_message', handleNewMessage);
      
      return () => {
        socket.off('new_message', handleNewMessage);
      };
    }
  }, [socket, tabValue]);

  // التمرير إلى أسفل قائمة الدردشة عند إضافة رسائل جديدة
  useEffect(() => {
    if (chatListRef.current) {
      chatListRef.current.scrollTop = chatListRef.current.scrollHeight;
    }
  }, [messages]);

  // تغيير علامة التبويب
  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
    
    // إعادة تعيين عدد الرسائل غير المقروءة عند الانتقال إلى تبويب الدردشة
    if (newValue === 0) {
      setUnreadMessages(0);
    }
  };

  // إرسال رسالة
  const handleSendMessage = () => {
    if (!message.trim()) return;
    
    dispatch(sendChatMessage(sessionId, message));
    
    // محاكاة إرسال رسالة (سيتم استبداله بالمنطق الفعلي)
    const newMessage = {
      _id: `m${Date.now()}`,
      sender: {
        _id: userInfo._id,
        fullName: userInfo.fullName,
        role: userInfo.role,
        avatar: userInfo.avatar || 'https://via.placeholder.com/150'
      },
      text: message,
      timestamp: new Date().toISOString()
    };
    
    setMessages([...messages, newMessage]);
    setMessage('');
    
    if (socket) {
      socket.emit('send_message', { sessionId, message });
    }
  };

  // الانضمام إلى الجلسة المباشرة
  const handleJoinSession = async () => {
    try {
      dispatch(joinLiveSession(sessionId));
      
      // محاكاة الانضمام إلى الجلسة (سيتم استبداله بالمنطق الفعلي)
      setIsJoined(true);
      
      // محاكاة إضافة المستخدم إلى قائمة المشاركين
      const newParticipant = {
        _id: userInfo._id,
        fullName: userInfo.fullName,
        role: userInfo.role,
        avatar: userInfo.avatar || 'https://via.placeholder.com/150',
        isActive: true,
        joinedAt: new Date().toISOString()
      };
      
      setParticipants([...participants, newParticipant]);
      
      // محاكاة إرسال رسالة نظام
      const systemMessage = {
        _id: `m${Date.now()}`,
        sender: {
          _id: 'system',
          fullName: 'النظام',
          role: 'system',
          avatar: ''
        },
        text: `${userInfo.fullName} انضم إلى الجلسة`,
        timestamp: new Date().toISOString(),
        isSystemMessage: true
      };
      
      setMessages([...messages, systemMessage]);
      
      if (socket) {
        socket.emit('join_session', { sessionId, userId: userInfo._id });
      }
    } catch (error) {
      setError('حدث خطأ أثناء الانضمام إلى الجلسة. يرجى المحاولة مرة أخرى.');
    }
  };

  // مغادرة الجلسة المباشرة
  const handleLeaveSession = () => {
    dispatch(leaveLiveSession(sessionId));
    
    // محاكاة مغادرة الجلسة (سيتم استبداله بالمنطق الفعلي)
    setIsJoined(false);
    setIsMicEnabled(false);
    setIsCameraEnabled(false);
    setIsScreenSharing(false);
    
    // محاكاة تحديث حالة المستخدم في قائمة المشاركين
    const updatedParticipants = participants.map(p => {
      if (p._id === userInfo._id) {
        return {
          ...p,
          isActive: false,
          leftAt: new Date().toISOString()
        };
      }
      return p;
    });
    
    setParticipants(updatedParticipants);
    
    // محاكاة إرسال رسالة نظام
    const systemMessage = {
      _id: `m${Date.now()}`,
      sender: {
        _id: 'system',
        fullName: 'النظام',
        role: 'system',
        avatar: ''
      },
      text: `${userInfo.fullName} غادر الجلسة`,
      timestamp: new Date().toISOString(),
      isSystemMessage: true
    };
    
    setMessages([...messages, systemMessage]);
    
    if (socket) {
      socket.emit('leave_session', { sessionId, userId: userInfo._id });
    }
  };

  // تبديل حالة الميكروفون
  const handleToggleMic = () => {
    setIsMicEnabled(!isMicEnabled);
    
    // هنا سيتم إضافة المنطق الفعلي لتمكين/تعطيل الميكروفون
  };

  // تبديل حالة الكاميرا
  const handleToggleCamera = () => {
    setIsCameraEnabled(!isCameraEnabled);
    
    // هنا سيتم إضافة المنطق الفعلي لتمكين/تعطيل الكاميرا
  };

  // تبديل حالة مشاركة الشاشة
  const handleToggleScreenShare = () => {
    setIsScreenSharing(!isScreenSharing);
    
    // هنا سيتم إضافة المنطق الفعلي لبدء/إيقاف مشاركة الشاشة
  };

  // تنسيق الوقت
  const formatTime = (timestamp) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  // عرض الدردشة
  const renderChat = () => {
    return (
      <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
        <Box
          ref={chatListRef}
          sx={{
            flexGrow: 1,
            overflowY: 'auto',
            p: 2,
            bgcolor: 'background.default',
            borderRadius: 1
          }}
        >
          <List>
            {messages.map((msg) => (
              <ListItem
                key={msg._id}
                alignItems="flex-start"
                sx={{
                  flexDirection: msg.sender._id === userInfo._id ? 'row-reverse' : 'row',
                  mb: 1
                }}
              >
                {!msg.isSystemMessage && (
                  <ListItemAvatar>
                    <Avatar
                      src={msg.sender.avatar}
                      alt={msg.sender.fullName}
                      sx={{
                        bgcolor: msg.sender.role === 'instructor' ? 'primary.main' : 'secondary.main'
                      }}
                    />
                  </ListItemAvatar>
                )}
                <ListItemText
                  primary={
                    <Box sx={{ display: 'flex', justifyContent: msg.sender._id === userInfo._id ? 'flex-end' : 'flex-start' }}>
                      {!msg.isSystemMessage && (
                        <Typography
                          variant="subtitle2"
                          sx={{
                            fontWeight: 'bold',
                            color: msg.sender.role === 'instructor' ? 'primary.main' : 'text.primary'
                          }}
                        >
                          {msg.sender.fullName}
                        </Typography>
                      )}
                    </Box>
                  }
                  secondary={
                    <Box>
                      <Typography
                        variant="body1"
                        sx={{
                          display: 'inline',
                          bgcolor: msg.isSystemMessage
                            ? 'grey.200'
                            : msg.sender._id === userInfo._id
                            ? 'primary.light'
                            : 'grey.100',
                          p: 1,
                          borderRadius: 2,
                          color: msg.isSystemMessage ? 'text.secondary' : 'text.primary',
                          fontStyle: msg.isSystemMessage ? 'italic' : 'normal',
                          textAlign: msg.sender._id === userInfo._id ? 'right' : 'left',
                          display: 'inline-block',
                          maxWidth: '80%'
                        }}
                      >
                        {msg.text}
                      </Typography>
                      <Typography
                        variant="caption"
                        sx={{
                          display: 'block',
                          textAlign: msg.sender._id === userInfo._id ? 'right' : 'left',
                          mt: 0.5
                        }}
                      >
                        {formatTime(msg.timestamp)}
                      </Typography>
                    </Box>
                  }
                />
              </ListItem>
            ))}
          </List>
        </Box>
        <Box sx={{ p: 2, borderTop: 1, borderColor: 'divider' }}>
          <Grid container spacing={1}>
            <Grid item xs>
              <TextField
                fullWidth
                placeholder="اكتب رسالتك هنا..."
                variant="outlined"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              />
            </Grid>
            <Grid item>
              <Button
                variant="contained"
                color="primary"
                endIcon={<SendIcon />}
                onClick={handleSendMessage}
                disabled={!message.trim()}
              >
                إرسال
              </Button>
            </Grid>
          </Grid>
        </Box>
      </Box>
    );
  };

  // عرض قائمة المشاركين
  const renderParticipants = () => {
    return (
      <Box sx={{ height: '100%', overflowY: 'auto', p: 2 }}>
        <Typography variant="h6" sx={{ mb: 2 }}>
          المشاركون ({participants.filter(p => p.isActive).length})
        </Typography>
        <List>
          {participants.map((participant) => (
            <React.Fragment key={participant._id}>
              <ListItem alignItems="flex-start">
                <ListItemAvatar>
                  <Avatar
                    src={participant.avatar}
                    alt={participant.fullName}
                    sx={{
                      bgcolor: participant.role === 'instructor' ? 'primary.main' : 'secondary.main',
                      opacity: participant.isActive ? 1 : 0.5
                    }}
                  />
                </ListItemAvatar>
                <ListItemText
                  primary={
                    <Typography
                      variant="subtitle1"
                      sx={{
                        fontWeight: participant.role === 'instructor' ? 'bold' : 'normal',
                        color: !participant.isActive ? 'text.disabled' : 'text.primary'
                      }}
                    >
                      {participant.fullName}
                      {participant.role === 'instructor' && ' (المدرب)'}
                    </Typography>
                  }
                  secondary={
                    <Typography variant="body2" sx={{ color: 'text.secondary' }}>
                      {participant.isActive
                        ? `انضم ${formatTime(participant.joinedAt)}`
                        : `غادر ${formatTime(participant.leftAt)}`}
                    </Typography>
                  }
                />
              </ListItem>
              <Divider variant="inset" component="li" />
            </React.Fragment>
          ))}
        </List>
      </Box>
    );
  };

  return (
    <Container component="main" maxWidth="xl" dir="rtl" sx={{ mt: 2, mb: 4 }}>
      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
          <CircularProgress />
        </Box>
      ) : session ? (
        <Grid container spacing={2}>
          {/* عنوان الجلسة ومعلوماتها */}
          <Grid item xs={12}>
            <Paper elevation={3} sx={{ p: 2 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <Box>
                  <Typography variant="h5" sx={{ fontWeight: 'bold' }}>
                    {session.title.ar}
                  </Typography>
                  <Typography variant="body1" color="text.secondary">
                    {session.description.ar}
                  </Typography>
                  <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
                    المدرب: {session.instructor.fullName} | الدورة: {session.courseName.ar}
                  </Typography>
                </Box>
                <Box>
                  {!isJoined ? (
                    <Button
                      variant="contained"
                      color="primary"
                      size="large"
                      onClick={handleJoinSession}
                    >
                      انضمام إلى الجلسة
                    </Button>
                  ) : (
                    <Button
                      variant="outlined"
                      color="error"
                      size="large"
                      onClick={handleLeaveSession}
                    >
                      مغادرة الجلسة
                    </Button>
                  )}
                </Box>
              </Box>
            </Paper>
          </Grid>

          {/* فيديو البث المباشر */}
          <Grid item xs={12} md={8}>
            <Paper elevation={3} sx={{ p: 2, height: '100%' }}>
              <Box sx={{ position: 'relative', width: '100%', height: 500, bgcolor: 'black', borderRadius: 1 }}>
                {/* فيديو المدرب */}
                <video
                  ref={remoteVideoRef}
                  autoPlay
                  playsInline
                  poster="https://via.placeholder.com/800x500?text=Live+Session"
                  style={{ width: '100%', height: '100%', objectFit: 'contain' }}
                />
                
                {/* فيديو المستخدم (إذا كانت الكاميرا مفعلة) */}
                {isCameraEnabled && (
                  <Box
                    sx={{
                      position: 'absolute',
                      bottom: 16,
                      right: 16,
                      width: 200,
                      height: 150,
                      bgcolor: 'grey.800',
                      borderRadius: 1,
                      border: '2px solid white'
                    }}
                  >
                    <video
                      ref={localVideoRef}
                      autoPlay
                      playsInline
                      muted
                      style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                    />
                  </Box>
                )}
                
                {/* أزرار التحكم */}
                {isJoined && (
                  <Box
                    sx={{
                      position: 'absolute',
                      bottom: 16,
                      left: '50%',
                      transform: 'translateX(-50%)',
                      display: 'flex',
                      gap: 2,
                      bgcolor: 'rgba(0, 0, 0, 0.5)',
                      borderRadius: 8,
                      p: 1
                    }}
                  >
                    <IconButton
                      color={isMicEnabled ? 'primary' : 'default'}
                      onClick={handleToggleMic}
                      sx={{ bgcolor: 'white' }}
                    >
                      {isMicEnabled ? <MicIcon /> : <MicOffIcon />}
                    </IconButton>
                    <IconButton
                      color={isCameraEnabled ? 'primary' : 'default'}
                      onClick={handleToggleCamera}
                      sx={{ bgcolor: 'white' }}
                    >
                      {isCameraEnabled ? <VideocamIcon /> : <VideocamOffIcon />}
                    </IconButton>
                    <IconButton
                      color={isScreenSharing ? 'primary' : 'default'}
                      onClick={handleToggleScreenShare}
                      sx={{ bgcolor: 'white' }}
                    >
                      {isScreenSharing ? <StopScreenShareIcon /> : <ScreenShareIcon />}
                    </IconButton>
                  </Box>
                )}
              </Box>
            </Paper>
          </Grid>

          {/* الدردشة وقائمة المشاركين */}
          <Grid item xs={12} md={4}>
            <Paper elevation={3} sx={{ p: 2, height: '100%' }}>
              <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
                <Tabs value={tabValue} onChange={handleTabChange} aria-label="chat tabs">
                  <Tab 
                    label={
                      <Badge color="error" badgeContent={unreadMessages} max={99}>
                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                          <ChatIcon sx={{ mr: 1 }} />
                          الدردشة
                        </Box>
                      </Badge>
                    } 
                  />
                  <Tab 
                    label={
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <PeopleIcon sx={{ mr: 1 }} />
                        المشاركون
                      </Box>
                    } 
                  />
                </Tabs>
              </Box>
              <Box sx={{ height: 'calc(100% - 48px)', mt: 2 }}>
                {tabValue === 0 ? renderChat() : renderParticipants()}
              </Box>
            </Paper>
          </Grid>
        </Grid>
      ) : (
        <Alert severity="error">
          لم يتم العثور على الجلسة المباشرة المطلوبة.
        </Alert>
      )}
    </Container>
  );
};

export default LiveSessionScreen;
