import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Box,
  Container,
  Paper,
  Typography,
  CircularProgress,
  Alert,
  Grid,
  Card,
  CardContent,
  Radio,
  RadioGroup,
  FormControlLabel,
  FormControl,
  FormLabel,
  Checkbox,
  FormGroup,
  Button,
  Divider,
  LinearProgress
} from '@mui/material';

// سيتم استبدال هذا بإجراءات Redux الفعلية
const getQuizDetails = (id) => ({ type: 'GET_QUIZ_DETAILS_REQUEST', payload: id });
const submitQuizAnswers = (quizId, answers) => ({ 
  type: 'SUBMIT_QUIZ_ANSWERS_REQUEST', 
  payload: { quizId, answers } 
});

const QuizScreen = () => {
  const { id: quizId } = useParams();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  
  // سيتم استبدال هذا بحالة Redux الفعلية
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [quiz, setQuiz] = useState(null);
  const [quizResult, setQuizResult] = useState(null);
  
  const userLogin = useSelector((state) => state.userLogin);
  const { userInfo } = userLogin;

  // حالة الواجهة
  const [answers, setAnswers] = useState([]);
  const [timeLeft, setTimeLeft] = useState(0);
  const [quizStarted, setQuizStarted] = useState(false);

  // التحقق من صلاحيات المستخدم وتحميل تفاصيل الاختبار
  useEffect(() => {
    if (!userInfo) {
      navigate('/login');
    } else if (userInfo.role !== 'student') {
      navigate('/dashboard');
    } else {
      dispatch(getQuizDetails(quizId));
      
      // محاكاة تحميل البيانات (سيتم استبداله بالمنطق الفعلي)
      setLoading(true);
      setTimeout(() => {
        const mockQuiz = {
          _id: quizId,
          title: {
            ar: 'اختبار استراتيجيات البيع',
            en: 'Sales Strategies Quiz'
          },
          description: {
            ar: 'اختبار لقياس فهم استراتيجيات البيع',
            en: 'Quiz to measure understanding of sales strategies'
          },
          passingScore: 70,
          timeLimit: 10, // بالدقائق
          questions: [
            {
              _id: 'q1',
              type: 'single',
              text: {
                ar: 'ما هي أفضل استراتيجية للمبيعات للمنتجات ذات القيمة العالية؟',
                en: 'What is the best sales strategy for high-value products?'
              },
              options: [
                {
                  ar: 'البيع المباشر',
                  en: 'Direct selling'
                },
                {
                  ar: 'البيع عبر الإنترنت',
                  en: 'Online selling'
                },
                {
                  ar: 'البيع الاستشاري',
                  en: 'Consultative selling'
                },
                {
                  ar: 'البيع بالتجزئة',
                  en: 'Retail selling'
                }
              ],
              points: 10
            },
            {
              _id: 'q2',
              type: 'multiple',
              text: {
                ar: 'اختر جميع العناصر التي تعتبر من مكونات استراتيجية المبيعات الفعالة:',
                en: 'Select all elements that are components of an effective sales strategy:'
              },
              options: [
                {
                  ar: 'تحديد الجمهور المستهدف',
                  en: 'Identifying target audience'
                },
                {
                  ar: 'تحليل المنافسين',
                  en: 'Competitor analysis'
                },
                {
                  ar: 'تجاهل احتياجات العملاء',
                  en: 'Ignoring customer needs'
                },
                {
                  ar: 'وضع أهداف قابلة للقياس',
                  en: 'Setting measurable goals'
                }
              ],
              points: 15
            },
            {
              _id: 'q3',
              type: 'single',
              text: {
                ar: 'ما هو مفهوم "نقطة البيع الفريدة" (USP)؟',
                en: 'What is the concept of "Unique Selling Proposition" (USP)?'
              },
              options: [
                {
                  ar: 'سعر المنتج المرتفع',
                  en: 'High product price'
                },
                {
                  ar: 'ميزة تميز منتجك عن المنافسين',
                  en: 'Feature that differentiates your product from competitors'
                },
                {
                  ar: 'استراتيجية للتسويق عبر وسائل التواصل الاجتماعي',
                  en: 'Social media marketing strategy'
                },
                {
                  ar: 'طريقة لتقليل تكاليف الإنتاج',
                  en: 'Method to reduce production costs'
                }
              ],
              points: 10
            },
            {
              _id: 'q4',
              type: 'single',
              text: {
                ar: 'أي من الآتي يعتبر من مؤشرات الأداء الرئيسية (KPIs) لفريق المبيعات؟',
                en: 'Which of the following is considered a Key Performance Indicator (KPI) for a sales team?'
              },
              options: [
                {
                  ar: 'عدد الموظفين في الشركة',
                  en: 'Number of employees in the company'
                },
                {
                  ar: 'معدل تحويل العملاء المحتملين إلى عملاء فعليين',
                  en: 'Conversion rate of leads to customers'
                },
                {
                  ar: 'عدد زيارات موقع الشركة',
                  en: 'Number of company website visits'
                },
                {
                  ar: 'تكلفة المواد الخام',
                  en: 'Cost of raw materials'
                }
              ],
              points: 10
            },
            {
              _id: 'q5',
              type: 'multiple',
              text: {
                ar: 'ما هي مراحل دورة المبيعات النموذجية؟',
                en: 'What are the stages of a typical sales cycle?'
              },
              options: [
                {
                  ar: 'التعرف على العميل المحتمل',
                  en: 'Prospecting'
                },
                {
                  ar: 'تأهيل العميل المحتمل',
                  en: 'Qualifying'
                },
                {
                  ar: 'تقديم العرض',
                  en: 'Presentation'
                },
                {
                  ar: 'إغلاق الصفقة',
                  en: 'Closing'
                }
              ],
              points: 15
            }
          ]
        };
        
        setQuiz(mockQuiz);
        setTimeLeft(mockQuiz.timeLimit * 60); // تحويل الدقائق إلى ثوانٍ
        
        // تهيئة مصفوفة الإجابات
        const initialAnswers = mockQuiz.questions.map(question => ({
          questionId: question._id,
          type: question.type,
          answer: question.type === 'single' ? '' : []
        }));
        setAnswers(initialAnswers);
        
        setLoading(false);
      }, 1000);
    }
  }, [dispatch, navigate, userInfo, quizId]);

  // بدء العد التنازلي عند بدء الاختبار
  useEffect(() => {
    let timer;
    if (quizStarted && timeLeft > 0 && !quizResult) {
      timer = setTimeout(() => {
        setTimeLeft(timeLeft - 1);
      }, 1000);
    } else if (quizStarted && timeLeft === 0 && !quizResult) {
      // تقديم الاختبار تلقائيًا عند انتهاء الوقت
      handleSubmitQuiz();
    }
    
    return () => clearTimeout(timer);
  }, [quizStarted, timeLeft, quizResult]);

  // تحديث إجابة سؤال فردي
  const handleSingleAnswerChange = (questionIndex, value) => {
    const updatedAnswers = [...answers];
    updatedAnswers[questionIndex].answer = value;
    setAnswers(updatedAnswers);
  };

  // تحديث إجابة سؤال متعدد الاختيارات
  const handleMultipleAnswerChange = (questionIndex, value) => {
    const updatedAnswers = [...answers];
    const currentAnswers = [...updatedAnswers[questionIndex].answer];
    
    if (currentAnswers.includes(value)) {
      // إزالة الإجابة إذا كانت موجودة بالفعل
      updatedAnswers[questionIndex].answer = currentAnswers.filter(item => item !== value);
    } else {
      // إضافة الإجابة إذا لم تكن موجودة
      updatedAnswers[questionIndex].answer = [...currentAnswers, value];
    }
    
    setAnswers(updatedAnswers);
  };

  // بدء الاختبار
  const handleStartQuiz = () => {
    setQuizStarted(true);
  };

  // تقديم الاختبار
  const handleSubmitQuiz = () => {
    // التحقق من الإجابة على جميع الأسئلة
    const unansweredQuestions = answers.filter(answer => 
      (answer.type === 'single' && answer.answer === '') || 
      (answer.type === 'multiple' && answer.answer.length === 0)
    );
    
    if (unansweredQuestions.length > 0 && timeLeft > 0) {
      if (!window.confirm('لم تجب على جميع الأسئلة. هل ترغب في تقديم الاختبار على أي حال؟')) {
        return;
      }
    }
    
    setSubmitting(true);
    dispatch(submitQuizAnswers(quizId, answers));
    
    // محاكاة تقديم الاختبار (سيتم استبداله بالمنطق الفعلي)
    setTimeout(() => {
      // محاكاة نتائج الاختبار
      const mockResult = {
        score: 85,
        passed: true,
        answers: [
          {
            questionIndex: 0,
            userAnswer: '2',
            isCorrect: true
          },
          {
            questionIndex: 1,
            userAnswer: ['0', '1', '3'],
            isCorrect: true
          },
          {
            questionIndex: 2,
            userAnswer: '1',
            isCorrect: true
          },
          {
            questionIndex: 3,
            userAnswer: '1',
            isCorrect: true
          },
          {
            questionIndex: 4,
            userAnswer: ['0', '1', '2'],
            isCorrect: false
          }
        ]
      };
      
      setQuizResult(mockResult);
      setSubmitting(false);
    }, 1500);
  };

  // تنسيق الوقت المتبقي
  const formatTimeLeft = () => {
    const minutes = Math.floor(timeLeft / 60);
    const seconds = timeLeft % 60;
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  // عرض شاشة بدء الاختبار
  const renderQuizStart = () => {
    return (
      <Card variant="outlined" sx={{ mb: 3, p: 2 }}>
        <CardContent>
          <Typography variant="h5" sx={{ mb: 2, fontWeight: 'bold' }}>
            {quiz.title.ar}
          </Typography>
          
          <Typography variant="body1" sx={{ mb: 3 }}>
            {quiz.description.ar}
          </Typography>
          
          <Grid container spacing={2} sx={{ mb: 3 }}>
            <Grid item xs={12} sm={6}>
              <Typography variant="body2">
                <strong>عدد الأسئلة:</strong> {quiz.questions.length}
              </Typography>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Typography variant="body2">
                <strong>الوقت المخصص:</strong> {quiz.timeLimit} دقيقة
              </Typography>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Typography variant="body2">
                <strong>درجة النجاح:</strong> {quiz.passingScore}%
              </Typography>
            </Grid>
            <Grid item xs={12} sm={6}>
              <Typography variant="body2">
                <strong>الدرجة الكلية:</strong> {quiz.questions.reduce((sum, q) => sum + (q.points || 1), 0)} نقطة
              </Typography>
            </Grid>
          </Grid>
          
          <Alert severity="info" sx={{ mb: 3 }}>
            ملاحظة: بمجرد بدء الاختبار، سيبدأ العد التنازلي ولن تتمكن من إيقافه. تأكد من أنك مستعد قبل البدء.
          </Alert>
          
          <Box sx={{ display: 'flex', justifyContent: 'center' }}>
            <Button
              variant="contained"
              color="primary"
              size="large"
              onClick={handleStartQuiz}
            >
              بدء الاختبار
            </Button>
          </Box>
        </CardContent>
      </Card>
    );
  };

  // عرض أسئلة الاختبار
  const renderQuizQuestions = () => {
    return (
      <>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
          <Typography variant="h5" sx={{ fontWeight: 'bold' }}>
            {quiz.title.ar}
          </Typography>
          
          <Box sx={{ 
            display: 'flex', 
            alignItems: 'center', 
            bgcolor: timeLeft < 60 ? 'error.light' : 'primary.light',
            color: 'white',
            px: 2,
            py: 1,
            borderRadius: 2
          }}>
            <Typography variant="h6">
              الوقت المتبقي: {formatTimeLeft()}
            </Typography>
          </Box>
        </Box>
        
        {quiz.questions.map((question, index) => (
          <Card key={question._id} variant="outlined" sx={{ mb: 3, p: 2 }}>
            <CardContent>
              <Typography variant="h6" sx={{ mb: 2 }}>
                السؤال {index + 1}: {question.text.ar} ({question.points} نقاط)
              </Typography>
              
              {question.type === 'single' ? (
                <FormControl component="fieldset" sx={{ width: '100%' }}>
                  <RadioGroup
                    value={answers[index]?.answer || ''}
                    onChange={(e) => handleSingleAnswerChange(index, e.target.value)}
                  >
                    {question.options.map((option, optionIndex) => (
                      <FormControlLabel
                        key={optionIndex}
                        value={optionIndex.toString()}
                        control={<Radio />}
                        label={option.ar}
                        sx={{ mb: 1 }}
                      />
                    ))}
                  </RadioGroup>
                </FormControl>
              ) : (
                <FormControl component="fieldset" sx={{ width: '100%' }}>
                  <FormGroup>
                    {question.options.map((option, optionIndex) => (
                      <FormControlLabel
                        key={optionIndex}
                        control={
                          <Checkbox
                            checked={answers[index]?.answer?.includes(optionIndex.toString()) || false}
                            onChange={() => handleMultipleAnswerChange(index, optionIndex.toString())}
                          />
                        }
                        label={option.ar}
                        sx={{ mb: 1 }}
                      />
                    ))}
                  </FormGroup>
                </FormControl>
              )}
            </CardContent>
          </Card>
        ))}
        
        <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
          <Button
            variant="contained"
            color="primary"
            size="large"
            onClick={handleSubmitQuiz}
            disabled={submitting}
          >
            {submitting ? <CircularProgress size={24} /> : 'تقديم الاختبار'}
          </Button>
        </Box>
      </>
    );
  };

  // عرض نتائج الاختبار
  const renderQuizResults = () => {
    return (
      <>
        <Box sx={{ textAlign: 'center', mb: 4 }}>
          <Typography variant="h5" sx={{ mb: 2, fontWeight: 'bold' }}>
            نتيجة الاختبار
          </Typography>
          
          <Typography variant="h4" sx={{ 
            color: quizResult.passed ? 'success.main' : 'error.main',
            fontWeight: 'bold',
            mb: 2
          }}>
            {quizResult.score}%
          </Typography>
          
          <Typography variant="h6" sx={{ 
            color: quizResult.passed ? 'success.main' : 'error.main',
            mb: 3
          }}>
            {quizResult.passed ? 'مبروك! لقد اجتزت الاختبار بنجاح.' : 'للأسف، لم تجتز الاختبار. حاول مرة أخرى.'}
          </Typography>
          
          <LinearProgress 
            variant="determinate" 
            value={quizResult.score} 
            color={quizResult.passed ? 'success' : 'error'}
            sx={{ height: 10, borderRadius: 5, mb: 3 }}
          />
        </Box>
        
        <Divider sx={{ mb: 4 }} />
        
        <Typography variant="h6" sx={{ mb: 3 }}>
          مراجعة الإجابات:
        </Typography>
        
        {quiz.questions.map((question, index) => {
          const answer = quizResult.answers.find(a => a.questionIndex === index);
          const isCorrect = answer?.isCorrect;
          
          return (
            <Card 
              key={question._id} 
              variant="outlined" 
              sx={{ 
                mb: 3, 
                p: 2,
                borderColor: isCorrect ? 'success.main' : 'error.main',
                borderWidth: 2
              }}
            >
              <CardContent>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                  <Typography variant="h6">
                    السؤال {index + 1}: {question.text.ar}
                  </Typography>
                  
                  <Typography variant="body1" sx={{ 
                    color: isCorrect ? 'success.main' : 'error.main',
                    fontWeight: 'bold'
                  }}>
                    {isCorrect ? 'إجابة صحيحة' : 'إجابة خاطئة'}
                  </Typography>
                </Box>
                
                {question.type === 'single' ? (
                  <FormControl component="fieldset" sx={{ width: '100%' }}>
                    <RadioGroup value={answer?.userAnswer || ''}>
                      {question.options.map((option, optionIndex) => (
                        <FormControlLabel
                          key={optionIndex}
                          value={optionIndex.toString()}
                          control={<Radio disabled />}
                          label={option.ar}
                          sx={{ 
                            mb: 1,
                            color: answer?.userAnswer === optionIndex.toString() ? 
                              (isCorrect ? 'success.main' : 'error.main') : 'inherit'
                          }}
                        />
                      ))}
                    </RadioGroup>
                  </FormControl>
                ) : (
                  <FormControl component="fieldset" sx={{ width: '100%' }}>
                    <FormGroup>
                      {question.options.map((option, optionIndex) => (
                        <FormControlLabel
                          key={optionIndex}
                          control={
                            <Checkbox
                              checked={answer?.userAnswer?.includes(optionIndex.toString()) || false}
                              disabled
                            />
                          }
                          label={option.ar}
                          sx={{ 
                            mb: 1,
                            color: answer?.userAnswer?.includes(optionIndex.toString()) ? 
                              (isCorrect ? 'success.main' : 'error.main') : 'inherit'
                          }}
                        />
                      ))}
                    </FormGroup>
                  </FormControl>
                )}
              </CardContent>
            </Card>
          );
        })}
        
        <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
          <Button
            variant="contained"
            color="primary"
            onClick={() => navigate(-1)}
          >
            العودة إلى الدورة
          </Button>
        </Box>
      </>
    );
  };

  return (
    <Container component="main" maxWidth="md" dir="rtl">
      <Paper
        elevation={3}
        sx={{
          marginTop: 4,
          marginBottom: 4,
          padding: 4,
        }}
      >
        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4, mb: 4 }}>
            <CircularProgress />
          </Box>
        ) : quiz ? (
          <>
            {error && <Alert severity="error" sx={{ mb: 3 }}>{error}</Alert>}
            
            {!quizStarted && !quizResult && renderQuizStart()}
            {quizStarted && !quizResult && renderQuizQuestions()}
            {quizResult && renderQuizResults()}
          </>
        ) : (
          <Alert severity="error">
            لم يتم العثور على الاختبار المطلوب.
          </Alert>
        )}
      </Paper>
    </Container>
  );
};

export default QuizScreen;
