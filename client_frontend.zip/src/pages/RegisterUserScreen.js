import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import {
  Container,
  Paper,
  Typography,
  TextField,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Grid,
  Box,
  CircularProgress,
  Alert,
  Snackbar
} from '@mui/material';
import { useLanguage, getTranslation } from '../contexts/LanguageContext';

// سيتم استبدال هذا بإجراءات Redux الفعلية
const registerUser = (userData) => ({ type: 'USER_REGISTER_REQUEST', payload: userData });

const RegisterUserScreen = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { language } = useLanguage();
  
  // حالة النموذج
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [role, setRole] = useState('student');
  const [status, setStatus] = useState('active');
  
  // حالة التحقق
  const [errors, setErrors] = useState({});
  const [successMessage, setSuccessMessage] = useState('');
  const [openSnackbar, setOpenSnackbar] = useState(false);
  
  // حالة Redux (سيتم استبدالها بالحالة الفعلية)
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  
  // التحقق من صلاحيات المستخدم
  const userLogin = useSelector((state) => state.userLogin);
  const { userInfo } = userLogin;
  
  useEffect(() => {
    if (!userInfo || userInfo.role !== 'admin') {
      navigate('/login');
    }
  }, [navigate, userInfo]);
  
  // التحقق من صحة النموذج
  const validateForm = () => {
    const newErrors = {};
    
    if (!fullName.trim()) {
      newErrors.fullName = getTranslation('users.fullName', language) + ' ' + getTranslation('general.error.required', language);
    }
    
    if (!email.trim()) {
      newErrors.email = getTranslation('auth.email', language) + ' ' + getTranslation('general.error.required', language);
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      newErrors.email = getTranslation('general.error.invalidEmail', language);
    }
    
    if (!username.trim()) {
      newErrors.username = getTranslation('auth.username', language) + ' ' + getTranslation('general.error.required', language);
    } else if (username.length < 4) {
      newErrors.username = getTranslation('general.error.minLength', language).replace('{field}', getTranslation('auth.username', language)).replace('{length}', '4');
    }
    
    if (!password) {
      newErrors.password = getTranslation('auth.password', language) + ' ' + getTranslation('general.error.required', language);
    } else if (password.length < 6) {
      newErrors.password = getTranslation('general.error.minLength', language).replace('{field}', getTranslation('auth.password', language)).replace('{length}', '6');
    }
    
    if (password !== confirmPassword) {
      newErrors.confirmPassword = getTranslation('general.error.passwordMismatch', language);
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  // إرسال النموذج
  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (validateForm()) {
      const userData = {
        fullName,
        email,
        username,
        password,
        role,
        status
      };
      
      dispatch(registerUser(userData));
      
      // محاكاة عملية التسجيل (سيتم استبدالها بالمنطق الفعلي)
      setLoading(true);
      setTimeout(() => {
        setLoading(false);
        setSuccessMessage(getTranslation('users.userCreated', language));
        setOpenSnackbar(true);
        
        // إعادة تعيين النموذج
        setFullName('');
        setEmail('');
        setUsername('');
        setPassword('');
        setConfirmPassword('');
        setRole('student');
        setStatus('active');
      }, 1500);
    }
  };
  
  // إغلاق Snackbar
  const handleCloseSnackbar = () => {
    setOpenSnackbar(false);
  };
  
  return (
    <Container component="main" maxWidth="md" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      <Paper
        elevation={3}
        sx={{
          marginTop: 4,
          marginBottom: 4,
          padding: 4,
        }}
      >
        <Typography component="h1" variant="h5" align="center" gutterBottom>
          {getTranslation('users.createUser', language)}
        </Typography>
        
        {error && <Alert severity="error" sx={{ mb: 3 }}>{error}</Alert>}
        
        <Box component="form" onSubmit={handleSubmit} noValidate>
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <TextField
                required
                fullWidth
                id="fullName"
                label={getTranslation('users.fullName', language)}
                name="fullName"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                error={!!errors.fullName}
                helperText={errors.fullName}
              />
            </Grid>
            
            <Grid item xs={12} md={6}>
              <TextField
                required
                fullWidth
                id="email"
                label={getTranslation('auth.email', language)}
                name="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                error={!!errors.email}
                helperText={errors.email}
              />
            </Grid>
            
            <Grid item xs={12} md={6}>
              <TextField
                required
                fullWidth
                id="username"
                label={getTranslation('auth.username', language)}
                name="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                error={!!errors.username}
                helperText={errors.username}
              />
            </Grid>
            
            <Grid item xs={12} md={6}>
              <TextField
                required
                fullWidth
                id="password"
                label={getTranslation('auth.password', language)}
                name="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                error={!!errors.password}
                helperText={errors.password}
              />
            </Grid>
            
            <Grid item xs={12} md={6}>
              <TextField
                required
                fullWidth
                id="confirmPassword"
                label={getTranslation('auth.confirmPassword', language)}
                name="confirmPassword"
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                error={!!errors.confirmPassword}
                helperText={errors.confirmPassword}
              />
            </Grid>
            
            <Grid item xs={12} md={6}>
              <FormControl fullWidth>
                <InputLabel id="role-label">{getTranslation('users.role', language)}</InputLabel>
                <Select
                  labelId="role-label"
                  id="role"
                  value={role}
                  label={getTranslation('users.role', language)}
                  onChange={(e) => setRole(e.target.value)}
                >
                  <MenuItem value="admin">{getTranslation('users.admin', language)}</MenuItem>
                  <MenuItem value="instructor">{getTranslation('users.instructor', language)}</MenuItem>
                  <MenuItem value="student">{getTranslation('users.student', language)}</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            
            <Grid item xs={12} md={6}>
              <FormControl fullWidth>
                <InputLabel id="status-label">{getTranslation('users.status', language)}</InputLabel>
                <Select
                  labelId="status-label"
                  id="status"
                  value={status}
                  label={getTranslation('users.status', language)}
                  onChange={(e) => setStatus(e.target.value)}
                >
                  <MenuItem value="active">{getTranslation('users.active', language)}</MenuItem>
                  <MenuItem value="inactive">{getTranslation('users.inactive', language)}</MenuItem>
                </Select>
              </FormControl>
            </Grid>
            
            <Grid item xs={12} sx={{ mt: 2 }}>
              <Button
                type="submit"
                fullWidth
                variant="contained"
                color="primary"
                size="large"
                disabled={loading}
                sx={{ py: 1.5 }}
              >
                {loading ? (
                  <CircularProgress size={24} />
                ) : (
                  getTranslation('users.createUser', language)
                )}
              </Button>
            </Grid>
          </Grid>
        </Box>
      </Paper>
      
      <Snackbar
        open={openSnackbar}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert onClose={handleCloseSnackbar} severity="success" sx={{ width: '100%' }}>
          {successMessage}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default RegisterUserScreen;
