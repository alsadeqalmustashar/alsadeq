import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import {
  Container,
  Paper,
  Typography,
  Box,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Chip,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  TextField,
  CircularProgress,
  Alert,
  Snackbar,
  Tooltip,
  Pagination
} from '@mui/material';
import {
  Edit as EditIcon,
  Delete as DeleteIcon,
  Add as AddIcon,
  Search as SearchIcon
} from '@mui/icons-material';
import { useLanguage, getTranslation } from '../contexts/LanguageContext';

// سيتم استبدال هذا بإجراءات Redux الفعلية
const listUsers = () => ({ type: 'USER_LIST_REQUEST' });
const deleteUser = (id) => ({ type: 'USER_DELETE_REQUEST', payload: id });

const UserListScreen = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { language } = useLanguage();
  
  // حالة الواجهة
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [usersPerPage] = useState(10);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [userToDelete, setUserToDelete] = useState(null);
  const [successMessage, setSuccessMessage] = useState('');
  const [openSnackbar, setOpenSnackbar] = useState(false);
  
  // حالة Redux (سيتم استبدالها بالحالة الفعلية)
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [users, setUsers] = useState([]);
  
  // التحقق من صلاحيات المستخدم
  const userLogin = useSelector((state) => state.userLogin);
  const { userInfo } = userLogin;
  
  useEffect(() => {
    if (!userInfo || userInfo.role !== 'admin') {
      navigate('/login');
    } else {
      dispatch(listUsers());
      
      // محاكاة تحميل البيانات (سيتم استبدالها بالمنطق الفعلي)
      setLoading(true);
      setTimeout(() => {
        const mockUsers = [
          {
            _id: '1',
            fullName: 'صادق زيدان',
            username: 'sadeq',
            email: 'sadeq@example.com',
            role: 'admin',
            status: 'active',
            lastLogin: new Date().toISOString()
          },
          {
            _id: '2',
            fullName: 'أحمد محمد',
            username: 'ahmed',
            email: 'ahmed@example.com',
            role: 'instructor',
            status: 'active',
            lastLogin: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString()
          },
          {
            _id: '3',
            fullName: 'سارة علي',
            username: 'sara',
            email: 'sara@example.com',
            role: 'instructor',
            status: 'active',
            lastLogin: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString()
          },
          {
            _id: '4',
            fullName: 'محمد خالد',
            username: 'mohammed',
            email: 'mohammed@example.com',
            role: 'student',
            status: 'active',
            lastLogin: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString()
          },
          {
            _id: '5',
            fullName: 'فاطمة أحمد',
            username: 'fatima',
            email: 'fatima@example.com',
            role: 'student',
            status: 'active',
            lastLogin: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString()
          },
          {
            _id: '6',
            fullName: 'علي حسن',
            username: 'ali',
            email: 'ali@example.com',
            role: 'student',
            status: 'inactive',
            lastLogin: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString()
          }
        ];
        
        setUsers(mockUsers);
        setLoading(false);
      }, 1000);
    }
  }, [dispatch, navigate, userInfo]);
  
  // فتح مربع حوار الحذف
  const openDeleteDialog = (user) => {
    setUserToDelete(user);
    setDeleteDialogOpen(true);
  };
  
  // إغلاق مربع حوار الحذف
  const closeDeleteDialog = () => {
    setDeleteDialogOpen(false);
    setUserToDelete(null);
  };
  
  // حذف المستخدم
  const confirmDelete = () => {
    if (userToDelete) {
      dispatch(deleteUser(userToDelete._id));
      
      // محاكاة عملية الحذف (سيتم استبدالها بالمنطق الفعلي)
      setLoading(true);
      setTimeout(() => {
        setUsers(users.filter(user => user._id !== userToDelete._id));
        setSuccessMessage(getTranslation('users.userDeleted', language));
        setOpenSnackbar(true);
        setLoading(false);
        closeDeleteDialog();
      }, 1000);
    }
  };
  
  // الانتقال إلى صفحة إنشاء مستخدم جديد
  const handleCreateUser = () => {
    navigate('/admin/user/register');
  };
  
  // الانتقال إلى صفحة تعديل المستخدم
  const handleEditUser = (id) => {
    navigate(`/admin/user/${id}/edit`);
  };
  
  // تصفية المستخدمين حسب البحث
  const filteredUsers = users.filter(user => 
    user.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  // حساب الصفحات
  const indexOfLastUser = currentPage * usersPerPage;
  const indexOfFirstUser = indexOfLastUser - usersPerPage;
  const currentUsers = filteredUsers.slice(indexOfFirstUser, indexOfLastUser);
  const totalPages = Math.ceil(filteredUsers.length / usersPerPage);
  
  // تغيير الصفحة
  const handlePageChange = (event, value) => {
    setCurrentPage(value);
  };
  
  // تنسيق التاريخ
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };
  
  // إغلاق Snackbar
  const handleCloseSnackbar = () => {
    setOpenSnackbar(false);
  };
  
  return (
    <Container component="main" maxWidth="lg" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      <Paper
        elevation={3}
        sx={{
          marginTop: 4,
          marginBottom: 4,
          padding: 4,
        }}
      >
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 4 }}>
          <Typography component="h1" variant="h5">
            {getTranslation('users.usersList', language)}
          </Typography>
          
          <Button
            variant="contained"
            color="primary"
            startIcon={<AddIcon />}
            onClick={handleCreateUser}
          >
            {getTranslation('users.createUser', language)}
          </Button>
        </Box>
        
        {error && <Alert severity="error" sx={{ mb: 3 }}>{error}</Alert>}
        
        <Box sx={{ display: 'flex', mb: 3 }}>
          <TextField
            fullWidth
            variant="outlined"
            placeholder={getTranslation('general.search', language)}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            InputProps={{
              startAdornment: <SearchIcon sx={{ mr: 1, color: 'text.secondary' }} />,
            }}
            sx={{ maxWidth: 500 }}
          />
        </Box>
        
        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', my: 4 }}>
            <CircularProgress />
          </Box>
        ) : (
          <>
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>{getTranslation('users.fullName', language)}</TableCell>
                    <TableCell>{getTranslation('auth.username', language)}</TableCell>
                    <TableCell>{getTranslation('auth.email', language)}</TableCell>
                    <TableCell>{getTranslation('users.role', language)}</TableCell>
                    <TableCell>{getTranslation('users.status', language)}</TableCell>
                    <TableCell>{getTranslation('users.lastLogin', language)}</TableCell>
                    <TableCell align="center">{getTranslation('general.actions', language)}</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {currentUsers.length > 0 ? (
                    currentUsers.map((user) => (
                      <TableRow key={user._id}>
                        <TableCell>{user.fullName}</TableCell>
                        <TableCell>{user.username}</TableCell>
                        <TableCell>{user.email}</TableCell>
                        <TableCell>
                          <Chip
                            label={getTranslation(`users.${user.role}`, language)}
                            color={
                              user.role === 'admin'
                                ? 'primary'
                                : user.role === 'instructor'
                                ? 'secondary'
                                : 'default'
                            }
                            size="small"
                          />
                        </TableCell>
                        <TableCell>
                          <Chip
                            label={getTranslation(`users.${user.status}`, language)}
                            color={user.status === 'active' ? 'success' : 'error'}
                            size="small"
                          />
                        </TableCell>
                        <TableCell>{formatDate(user.lastLogin)}</TableCell>
                        <TableCell align="center">
                          <Tooltip title={getTranslation('users.editUser', language)}>
                            <IconButton
                              color="primary"
                              onClick={() => handleEditUser(user._id)}
                            >
                              <EditIcon />
                            </IconButton>
                          </Tooltip>
                          <Tooltip title={getTranslation('users.deleteUser', language)}>
                            <IconButton
                              color="error"
                              onClick={() => openDeleteDialog(user)}
                            >
                              <DeleteIcon />
                            </IconButton>
                          </Tooltip>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={7} align="center">
                        {getTranslation('general.noResults', language)}
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </TableContainer>
            
            {filteredUsers.length > usersPerPage && (
              <Box sx={{ display: 'flex', justifyContent: 'center', mt: 3 }}>
                <Pagination
                  count={totalPages}
                  page={currentPage}
                  onChange={handlePageChange}
                  color="primary"
                />
              </Box>
            )}
          </>
        )}
      </Paper>
      
      {/* مربع حوار تأكيد الحذف */}
      <Dialog
        open={deleteDialogOpen}
        onClose={closeDeleteDialog}
      >
        <DialogTitle>{getTranslation('users.deleteUser', language)}</DialogTitle>
        <DialogContent>
          <DialogContentText>
            {getTranslation('general.confirmDelete', language)}
            {userToDelete && (
              <strong> {userToDelete.fullName}</strong>
            )}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={closeDeleteDialog} color="primary">
            {getTranslation('general.cancel', language)}
          </Button>
          <Button onClick={confirmDelete} color="error" autoFocus>
            {getTranslation('general.delete', language)}
          </Button>
        </DialogActions>
      </Dialog>
      
      <Snackbar
        open={openSnackbar}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert onClose={handleCloseSnackbar} severity="success" sx={{ width: '100%' }}>
          {successMessage}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default UserListScreen;
