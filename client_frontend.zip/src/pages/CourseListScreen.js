import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  TextField,
  Button,
  Typography,
  Box,
  Container,
  Paper,
  CircularProgress,
  Alert,
  Grid,
  Card,
  CardContent,
  CardMedia,
  CardActions,
  IconButton,
  Chip,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  FormControlLabel,
  Switch
} from '@mui/material';
import { Add as AddIcon, Edit as EditIcon, Delete as DeleteIcon } from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';

// سيتم استبدال هذا بإجراءات Redux الفعلية
const getCourses = () => ({ type: 'GET_COURSES_REQUEST' });
const deleteCourse = (id) => ({ type: 'DELETE_COURSE_REQUEST', payload: id });

const CourseListScreen = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  
  // سيتم استبدال هذا بحالة Redux الفعلية
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [courses, setCourses] = useState([]);
  const [successDelete, setSuccessDelete] = useState(false);
  
  const userLogin = useSelector((state) => state.userLogin);
  const { userInfo } = userLogin;

  // التحقق من صلاحيات المستخدم وتحميل قائمة الدورات
  useEffect(() => {
    if (!userInfo) {
      navigate('/login');
    } else {
      dispatch(getCourses());
    }
  }, [dispatch, navigate, userInfo, successDelete]);

  // معالجة حذف الدورة
  const deleteHandler = (id) => {
    if (window.confirm('هل أنت متأكد من حذف هذه الدورة؟')) {
      dispatch(deleteCourse(id));
    }
  };

  // بيانات تجريبية للدورات
  useEffect(() => {
    setCourses([
      {
        _id: '1',
        title: {
          ar: 'مبادئ إدارة المبيعات',
          en: 'Sales Management Principles'
        },
        description: {
          ar: 'دورة شاملة في أساسيات إدارة المبيعات وتطوير استراتيجيات البيع',
          en: 'Comprehensive course in sales management fundamentals and strategy development'
        },
        instructor: {
          _id: '1',
          fullName: 'صادق زيدان'
        },
        thumbnail: 'https://via.placeholder.com/300x200?text=Sales+Management',
        isPublished: true,
        enrolledStudents: ['101', '102', '103'],
        modules: ['m1', 'm2', 'm3']
      },
      {
        _id: '2',
        title: {
          ar: 'التدريب الاحترافي',
          en: 'Professional Training'
        },
        description: {
          ar: 'تعلم أساليب التدريب الاحترافي وتطوير مهارات نقل المعرفة',
          en: 'Learn professional training methods and knowledge transfer skills'
        },
        instructor: {
          _id: '1',
          fullName: 'صادق زيدان'
        },
        thumbnail: 'https://via.placeholder.com/300x200?text=Professional+Training',
        isPublished: false,
        enrolledStudents: ['101'],
        modules: ['m4', 'm5']
      },
      {
        _id: '3',
        title: {
          ar: 'أساسيات المحاسبة',
          en: 'Accounting Fundamentals'
        },
        description: {
          ar: 'مقدمة في المحاسبة المالية والإدارية للمبتدئين',
          en: 'Introduction to financial and managerial accounting for beginners'
        },
        instructor: {
          _id: '2',
          fullName: 'أحمد محمد'
        },
        thumbnail: 'https://via.placeholder.com/300x200?text=Accounting',
        isPublished: true,
        enrolledStudents: ['102', '103', '104', '105'],
        modules: ['m6', 'm7', 'm8', 'm9']
      }
    ]);
  }, []);

  return (
    <Container component="main" maxWidth="lg" dir="rtl">
      <Paper
        elevation={3}
        sx={{
          marginTop: 4,
          marginBottom: 4,
          padding: 4,
        }}
      >
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
          <Typography component="h1" variant="h5" sx={{ fontWeight: 'bold' }}>
            إدارة الدورات التدريبية
          </Typography>
          <Button
            variant="contained"
            color="primary"
            startIcon={<AddIcon />}
            onClick={() => navigate('/course/create')}
          >
            إضافة دورة جديدة
          </Button>
        </Box>

        {error && <Alert severity="error" sx={{ width: '100%', mb: 2 }}>{error}</Alert>}
        {successDelete && <Alert severity="success" sx={{ width: '100%', mb: 2 }}>تم حذف الدورة بنجاح</Alert>}

        {loading ? (
          <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
            <CircularProgress />
          </Box>
        ) : (
          <Grid container spacing={3}>
            {courses.map((course) => (
              <Grid item xs={12} sm={6} md={4} key={course._id}>
                <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
                  <CardMedia
                    component="img"
                    height="140"
                    image={course.thumbnail}
                    alt={course.title.ar}
                  />
                  <CardContent sx={{ flexGrow: 1 }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
                      <Typography gutterBottom variant="h6" component="div">
                        {course.title.ar}
                      </Typography>
                      <Chip 
                        label={course.isPublished ? 'منشورة' : 'مسودة'} 
                        color={course.isPublished ? 'success' : 'default'}
                        size="small"
                      />
                    </Box>
                    <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                      {course.description.ar.length > 100 
                        ? `${course.description.ar.substring(0, 100)}...` 
                        : course.description.ar}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      المدرب: {course.instructor.fullName}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      عدد الطلاب: {course.enrolledStudents.length}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      عدد الوحدات: {course.modules.length}
                    </Typography>
                  </CardContent>
                  <CardActions sx={{ justifyContent: 'space-between', padding: 2 }}>
                    <Box>
                      <IconButton 
                        color="primary" 
                        onClick={() => navigate(`/course/${course._id}/edit`)}
                      >
                        <EditIcon />
                      </IconButton>
                      <IconButton 
                        color="error" 
                        onClick={() => deleteHandler(course._id)}
                      >
                        <DeleteIcon />
                      </IconButton>
                    </Box>
                    <Button 
                      size="small" 
                      variant="outlined"
                      onClick={() => navigate(`/course/${course._id}`)}
                    >
                      عرض التفاصيل
                    </Button>
                  </CardActions>
                </Card>
              </Grid>
            ))}
          </Grid>
        )}
      </Paper>
    </Container>
  );
};

export default CourseListScreen;
