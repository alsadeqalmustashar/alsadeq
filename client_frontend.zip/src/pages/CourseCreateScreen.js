import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  TextField,
  Button,
  Typography,
  Box,
  Container,
  Paper,
  CircularProgress,
  Alert,
  Grid,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  FormHelperText,
  Divider
} from '@mui/material';
import { useNavigate } from 'react-router-dom';

// سيتم استبدال هذا بإجراءات Redux الفعلية
const createCourse = (courseData) => ({ type: 'CREATE_COURSE_REQUEST', payload: courseData });

const CourseCreateScreen = () => {
  const [courseData, setCourseData] = useState({
    title: {
      ar: '',
      en: ''
    },
    description: {
      ar: '',
      en: ''
    },
    thumbnail: '',
    isPublished: false
  });

  const dispatch = useDispatch();
  const navigate = useNavigate();
  
  // سيتم استبدال هذا بحالة Redux الفعلية
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  
  const userLogin = useSelector((state) => state.userLogin);
  const { userInfo } = userLogin;

  // التحقق من صلاحيات المستخدم
  useEffect(() => {
    if (!userInfo || (userInfo.role !== 'admin' && userInfo.role !== 'instructor')) {
      navigate('/login');
    }
  }, [userInfo, navigate]);

  // إعادة التوجيه بعد الإنشاء الناجح
  useEffect(() => {
    if (success) {
      navigate('/courses');
    }
  }, [success, navigate]);

  // تحديث بيانات الدورة
  const handleChange = (e, language = null, field = null) => {
    if (language && field) {
      setCourseData({
        ...courseData,
        [field]: {
          ...courseData[field],
          [language]: e.target.value
        }
      });
    } else {
      setCourseData({
        ...courseData,
        [e.target.name]: e.target.value
      });
    }
  };

  // معالجة إنشاء الدورة
  const submitHandler = (e) => {
    e.preventDefault();
    
    // التحقق من البيانات المطلوبة
    if (!courseData.title.ar || !courseData.title.en || !courseData.description.ar || !courseData.description.en) {
      setError('يجب توفير العنوان والوصف باللغتين العربية والإنجليزية');
      return;
    }
    
    dispatch(createCourse(courseData));
    
    // محاكاة النجاح (سيتم استبداله بالمنطق الفعلي)
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setSuccess(true);
    }, 1500);
  };

  return (
    <Container component="main" maxWidth="md" dir="rtl">
      <Paper
        elevation={3}
        sx={{
          marginTop: 4,
          marginBottom: 4,
          padding: 4,
        }}
      >
        <Typography component="h1" variant="h5" sx={{ mb: 3, fontWeight: 'bold' }}>
          إنشاء دورة جديدة
        </Typography>

        {error && <Alert severity="error" sx={{ width: '100%', mb: 2 }}>{error}</Alert>}
        {success && <Alert severity="success" sx={{ width: '100%', mb: 2 }}>تم إنشاء الدورة بنجاح</Alert>}

        <Box component="form" onSubmit={submitHandler} sx={{ mt: 1 }}>
          <Typography variant="h6" sx={{ mb: 2 }}>
            معلومات الدورة باللغة العربية
          </Typography>
          
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <TextField
                required
                fullWidth
                label="عنوان الدورة (بالعربية)"
                value={courseData.title.ar}
                onChange={(e) => handleChange(e, 'ar', 'title')}
                sx={{ mb: 2 }}
              />
            </Grid>
            
            <Grid item xs={12}>
              <TextField
                required
                fullWidth
                label="وصف الدورة (بالعربية)"
                multiline
                rows={4}
                value={courseData.description.ar}
                onChange={(e) => handleChange(e, 'ar', 'description')}
                sx={{ mb: 3 }}
              />
            </Grid>
          </Grid>

          <Divider sx={{ my: 3 }} />

          <Typography variant="h6" sx={{ mb: 2 }}>
            معلومات الدورة باللغة الإنجليزية
          </Typography>
          
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <TextField
                required
                fullWidth
                label="عنوان الدورة (بالإنجليزية)"
                value={courseData.title.en}
                onChange={(e) => handleChange(e, 'en', 'title')}
                sx={{ mb: 2 }}
              />
            </Grid>
            
            <Grid item xs={12}>
              <TextField
                required
                fullWidth
                label="وصف الدورة (بالإنجليزية)"
                multiline
                rows={4}
                value={courseData.description.en}
                onChange={(e) => handleChange(e, 'en', 'description')}
                sx={{ mb: 3 }}
              />
            </Grid>
          </Grid>

          <Divider sx={{ my: 3 }} />

          <Typography variant="h6" sx={{ mb: 2 }}>
            إعدادات إضافية
          </Typography>
          
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="رابط الصورة المصغرة"
                name="thumbnail"
                value={courseData.thumbnail}
                onChange={handleChange}
                helperText="أدخل رابط URL للصورة المصغرة للدورة"
                sx={{ mb: 2 }}
              />
            </Grid>
            
            <Grid item xs={12}>
              <FormControl fullWidth sx={{ mb: 2 }}>
                <InputLabel id="published-label">حالة النشر</InputLabel>
                <Select
                  labelId="published-label"
                  name="isPublished"
                  value={courseData.isPublished}
                  label="حالة النشر"
                  onChange={handleChange}
                >
                  <MenuItem value={false}>مسودة (غير منشورة)</MenuItem>
                  <MenuItem value={true}>منشورة (متاحة للطلاب)</MenuItem>
                </Select>
                <FormHelperText>
                  الدورات المنشورة ستكون مرئية للطلاب المسجلين
                </FormHelperText>
              </FormControl>
            </Grid>
          </Grid>

          <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 4 }}>
            <Button
              variant="outlined"
              color="secondary"
              onClick={() => navigate('/courses')}
            >
              إلغاء
            </Button>
            <Button
              type="submit"
              variant="contained"
              color="primary"
              disabled={loading}
            >
              {loading ? <CircularProgress size={24} /> : 'إنشاء الدورة'}
            </Button>
          </Box>
        </Box>
      </Paper>
    </Container>
  );
};

export default CourseCreateScreen;
