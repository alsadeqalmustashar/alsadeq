import React from 'react';
import { Box, IconButton, Menu, MenuItem, Typography } from '@mui/material';
import { Language as LanguageIcon } from '@mui/icons-material';
import { useLanguage } from '../contexts/LanguageContext';

const LanguageSelector = ({ currentLanguage, onLanguageChange }) => {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const { translations } = useLanguage();
  
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleLanguageSelect = (language) => {
    onLanguageChange(language);
    handleClose();
  };

  return (
    <Box
      sx={{
        position: 'fixed',
        bottom: 20,
        right: 20,
        zIndex: 1000,
      }}
    >
      <IconButton
        aria-controls="language-menu"
        aria-haspopup="true"
        onClick={handleClick}
        sx={{
          bgcolor: 'primary.main',
          color: 'white',
          '&:hover': {
            bgcolor: 'primary.dark',
          },
        }}
      >
        <LanguageIcon />
      </IconButton>
      <Menu
        id="language-menu"
        anchorEl={anchorEl}
        keepMounted
        open={Boolean(anchorEl)}
        onClose={handleClose}
      >
        <MenuItem 
          onClick={() => handleLanguageSelect('ar')} 
          selected={currentLanguage === 'ar'}
        >
          <Typography>العربية</Typography>
        </MenuItem>
        <MenuItem 
          onClick={() => handleLanguageSelect('en')} 
          selected={currentLanguage === 'en'}
        >
          <Typography>English</Typography>
        </MenuItem>
      </Menu>
    </Box>
  );
};

export default LanguageSelector;
