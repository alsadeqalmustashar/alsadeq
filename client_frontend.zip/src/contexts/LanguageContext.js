import React, { createContext, useState, useContext } from 'react';

// إنشاء سياق اللغة
const LanguageContext = createContext();

// مزود سياق اللغة
export const LanguageProvider = ({ children, value }) => {
  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
};

// هوك استخدام سياق اللغة
export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

// الترجمات
export const translations = {
  // الترجمات العامة
  general: {
    appName: {
      ar: 'الصادق المستشار للاستشارات والتدريب',
      en: 'Al-Sadeq Al-Mustashar for Consulting and Training'
    },
    loading: {
      ar: 'جاري التحميل...',
      en: 'Loading...'
    },
    error: {
      ar: 'حدث خطأ',
      en: 'An error occurred'
    },
    success: {
      ar: 'تمت العملية بنجاح',
      en: 'Operation completed successfully'
    },
    save: {
      ar: 'حفظ',
      en: 'Save'
    },
    cancel: {
      ar: 'إلغاء',
      en: 'Cancel'
    },
    edit: {
      ar: 'تعديل',
      en: 'Edit'
    },
    delete: {
      ar: 'حذف',
      en: 'Delete'
    },
    create: {
      ar: 'إنشاء',
      en: 'Create'
    },
    submit: {
      ar: 'إرسال',
      en: 'Submit'
    },
    back: {
      ar: 'رجوع',
      en: 'Back'
    },
    next: {
      ar: 'التالي',
      en: 'Next'
    },
    previous: {
      ar: 'السابق',
      en: 'Previous'
    },
    search: {
      ar: 'بحث',
      en: 'Search'
    },
    filter: {
      ar: 'تصفية',
      en: 'Filter'
    },
    all: {
      ar: 'الكل',
      en: 'All'
    },
    yes: {
      ar: 'نعم',
      en: 'Yes'
    },
    no: {
      ar: 'لا',
      en: 'No'
    },
    confirmDelete: {
      ar: 'هل أنت متأكد من الحذف؟',
      en: 'Are you sure you want to delete?'
    }
  },
  
  // ترجمات الهيدر والتنقل
  navigation: {
    home: {
      ar: 'الرئيسية',
      en: 'Home'
    },
    dashboard: {
      ar: 'لوحة التحكم',
      en: 'Dashboard'
    },
    courses: {
      ar: 'الدورات',
      en: 'Courses'
    },
    users: {
      ar: 'المستخدمون',
      en: 'Users'
    },
    profile: {
      ar: 'الملف الشخصي',
      en: 'Profile'
    },
    login: {
      ar: 'تسجيل الدخول',
      en: 'Login'
    },
    logout: {
      ar: 'تسجيل الخروج',
      en: 'Logout'
    },
    adminPanel: {
      ar: 'لوحة الإدارة',
      en: 'Admin Panel'
    },
    instructorPanel: {
      ar: 'لوحة المدرب',
      en: 'Instructor Panel'
    },
    studentPanel: {
      ar: 'لوحة الطالب',
      en: 'Student Panel'
    }
  },
  
  // ترجمات المصادقة
  auth: {
    username: {
      ar: 'اسم المستخدم',
      en: 'Username'
    },
    email: {
      ar: 'البريد الإلكتروني',
      en: 'Email'
    },
    password: {
      ar: 'كلمة المرور',
      en: 'Password'
    },
    confirmPassword: {
      ar: 'تأكيد كلمة المرور',
      en: 'Confirm Password'
    },
    loginTitle: {
      ar: 'تسجيل الدخول',
      en: 'Login'
    },
    loginButton: {
      ar: 'تسجيل الدخول',
      en: 'Login'
    },
    registerTitle: {
      ar: 'تسجيل مستخدم جديد',
      en: 'Register New User'
    },
    registerButton: {
      ar: 'تسجيل',
      en: 'Register'
    },
    forgotPassword: {
      ar: 'نسيت كلمة المرور؟',
      en: 'Forgot Password?'
    },
    resetPassword: {
      ar: 'إعادة تعيين كلمة المرور',
      en: 'Reset Password'
    },
    loginError: {
      ar: 'اسم المستخدم أو كلمة المرور غير صحيحة',
      en: 'Invalid username or password'
    },
    logoutSuccess: {
      ar: 'تم تسجيل الخروج بنجاح',
      en: 'Logged out successfully'
    }
  },
  
  // ترجمات إدارة المستخدمين
  users: {
    fullName: {
      ar: 'الاسم الكامل',
      en: 'Full Name'
    },
    role: {
      ar: 'الدور',
      en: 'Role'
    },
    admin: {
      ar: 'مسؤول',
      en: 'Admin'
    },
    instructor: {
      ar: 'مدرب',
      en: 'Instructor'
    },
    student: {
      ar: 'طالب',
      en: 'Student'
    },
    status: {
      ar: 'الحالة',
      en: 'Status'
    },
    active: {
      ar: 'نشط',
      en: 'Active'
    },
    inactive: {
      ar: 'غير نشط',
      en: 'Inactive'
    },
    lastLogin: {
      ar: 'آخر تسجيل دخول',
      en: 'Last Login'
    },
    createUser: {
      ar: 'إنشاء مستخدم جديد',
      en: 'Create New User'
    },
    editUser: {
      ar: 'تعديل المستخدم',
      en: 'Edit User'
    },
    deleteUser: {
      ar: 'حذف المستخدم',
      en: 'Delete User'
    },
    usersList: {
      ar: 'قائمة المستخدمين',
      en: 'Users List'
    },
    userDetails: {
      ar: 'تفاصيل المستخدم',
      en: 'User Details'
    },
    userCreated: {
      ar: 'تم إنشاء المستخدم بنجاح',
      en: 'User created successfully'
    },
    userUpdated: {
      ar: 'تم تحديث المستخدم بنجاح',
      en: 'User updated successfully'
    },
    userDeleted: {
      ar: 'تم حذف المستخدم بنجاح',
      en: 'User deleted successfully'
    }
  },
  
  // ترجمات إدارة الدورات
  courses: {
    title: {
      ar: 'العنوان',
      en: 'Title'
    },
    description: {
      ar: 'الوصف',
      en: 'Description'
    },
    instructor: {
      ar: 'المدرب',
      en: 'Instructor'
    },
    thumbnail: {
      ar: 'الصورة المصغرة',
      en: 'Thumbnail'
    },
    status: {
      ar: 'الحالة',
      en: 'Status'
    },
    published: {
      ar: 'منشورة',
      en: 'Published'
    },
    draft: {
      ar: 'مسودة',
      en: 'Draft'
    },
    enrolledStudents: {
      ar: 'الطلاب المسجلين',
      en: 'Enrolled Students'
    },
    modules: {
      ar: 'الوحدات',
      en: 'Modules'
    },
    createCourse: {
      ar: 'إنشاء دورة جديدة',
      en: 'Create New Course'
    },
    editCourse: {
      ar: 'تعديل الدورة',
      en: 'Edit Course'
    },
    deleteCourse: {
      ar: 'حذف الدورة',
      en: 'Delete Course'
    },
    coursesList: {
      ar: 'قائمة الدورات',
      en: 'Courses List'
    },
    courseDetails: {
      ar: 'تفاصيل الدورة',
      en: 'Course Details'
    },
    courseCreated: {
      ar: 'تم إنشاء الدورة بنجاح',
      en: 'Course created successfully'
    },
    courseUpdated: {
      ar: 'تم تحديث الدورة بنجاح',
      en: 'Course updated successfully'
    },
    courseDeleted: {
      ar: 'تم حذف الدورة بنجاح',
      en: 'Course deleted successfully'
    },
    enrollStudent: {
      ar: 'تسجيل طالب',
      en: 'Enroll Student'
    },
    unenrollStudent: {
      ar: 'إلغاء تسجيل طالب',
      en: 'Unenroll Student'
    },
    studentEnrolled: {
      ar: 'تم تسجيل الطالب بنجاح',
      en: 'Student enrolled successfully'
    },
    studentUnenrolled: {
      ar: 'تم إلغاء تسجيل الطالب بنجاح',
      en: 'Student unenrolled successfully'
    }
  },
  
  // ترجمات الوحدات والمحتوى
  modules: {
    title: {
      ar: 'العنوان',
      en: 'Title'
    },
    description: {
      ar: 'الوصف',
      en: 'Description'
    },
    order: {
      ar: 'الترتيب',
      en: 'Order'
    },
    content: {
      ar: 'المحتوى',
      en: 'Content'
    },
    createModule: {
      ar: 'إنشاء وحدة جديدة',
      en: 'Create New Module'
    },
    editModule: {
      ar: 'تعديل الوحدة',
      en: 'Edit Module'
    },
    deleteModule: {
      ar: 'حذف الوحدة',
      en: 'Delete Module'
    },
    moduleCreated: {
      ar: 'تم إنشاء الوحدة بنجاح',
      en: 'Module created successfully'
    },
    moduleUpdated: {
      ar: 'تم تحديث الوحدة بنجاح',
      en: 'Module updated successfully'
    },
    moduleDeleted: {
      ar: 'تم حذف الوحدة بنجاح',
      en: 'Module deleted successfully'
    },
    contentTypes: {
      video: {
        ar: 'فيديو',
        en: 'Video'
      },
      pdf: {
        ar: 'ملف PDF',
        en: 'PDF File'
      },
      quiz: {
        ar: 'اختبار',
        en: 'Quiz'
      }
    },
    addContent: {
      ar: 'إضافة محتوى',
      en: 'Add Content'
    },
    editContent: {
      ar: 'تعديل المحتوى',
      en: 'Edit Content'
    },
    deleteContent: {
      ar: 'حذف المحتوى',
      en: 'Delete Content'
    },
    contentCreated: {
      ar: 'تم إضافة المحتوى بنجاح',
      en: 'Content added successfully'
    },
    contentUpdated: {
      ar: 'تم تحديث المحتوى بنجاح',
      en: 'Content updated successfully'
    },
    contentDeleted: {
      ar: 'تم حذف المحتوى بنجاح',
      en: 'Content deleted successfully'
    },
    fileUrl: {
      ar: 'رابط الملف',
      en: 'File URL'
    },
    duration: {
      ar: 'المدة',
      en: 'Duration'
    },
    minutes: {
      ar: 'دقائق',
      en: 'minutes'
    }
  },
  
  // ترجمات الاختبارات
  quizzes: {
    title: {
      ar: 'العنوان',
      en: 'Title'
    },
    description: {
      ar: 'الوصف',
      en: 'Description'
    },
    passingScore: {
      ar: 'درجة النجاح',
      en: 'Passing Score'
    },
    timeLimit: {
      ar: 'الوقت المحدد',
      en: 'Time Limit'
    },
    questions: {
      ar: 'الأسئلة',
      en: 'Questions'
    },
    createQuiz: {
      ar: 'إنشاء اختبار جديد',
      en: 'Create New Quiz'
    },
    editQuiz: {
      ar: 'تعديل الاختبار',
      en: 'Edit Quiz'
    },
    deleteQuiz: {
      ar: 'حذف الاختبار',
      en: 'Delete Quiz'
    },
    quizCreated: {
      ar: 'تم إنشاء الاختبار بنجاح',
      en: 'Quiz created successfully'
    },
    quizUpdated: {
      ar: 'تم تحديث الاختبار بنجاح',
      en: 'Quiz updated successfully'
    },
    quizDeleted: {
      ar: 'تم حذف الاختبار بنجاح',
      en: 'Quiz deleted successfully'
    },
    questionTypes: {
      single: {
        ar: 'اختيار واحد',
        en: 'Single Choice'
      },
      multiple: {
        ar: 'اختيار متعدد',
        en: 'Multiple Choice'
      }
    },
    questionText: {
      ar: 'نص السؤال',
      en: 'Question Text'
    },
    options: {
      ar: 'الخيارات',
      en: 'Options'
    },
    correctAnswer: {
      ar: 'الإجابة الصحيحة',
      en: 'Correct Answer'
    },
    points: {
      ar: 'النقاط',
      en: 'Points'
    },
    addQuestion: {
      ar: 'إضافة سؤال',
      en: 'Add Question'
    },
    editQuestion: {
      ar: 'تعديل السؤال',
      en: 'Edit Question'
    },
    deleteQuestion: {
      ar: 'حذف السؤال',
      en: 'Delete Question'
    },
    startQuiz: {
      ar: 'بدء الاختبار',
      en: 'Start Quiz'
    },
    submitQuiz: {
      ar: 'تقديم الاختبار',
      en: 'Submit Quiz'
    },
    quizResults: {
      ar: 'نتائج الاختبار',
      en: 'Quiz Results'
    },
    passed: {
      ar: 'نجاح',
      en: 'Passed'
    },
    failed: {
      ar: 'رسوب',
      en: 'Failed'
    },
    score: {
      ar: 'الدرجة',
      en: 'Score'
    },
    timeLeft: {
      ar: 'الوقت المتبقي',
      en: 'Time Left'
    },
    correctAnswers: {
      ar: 'الإجابات الصحيحة',
      en: 'Correct Answers'
    },
    wrongAnswers: {
      ar: 'الإجابات الخاطئة',
      en: 'Wrong Answers'
    },
    reviewAnswers: {
      ar: 'مراجعة الإجابات',
      en: 'Review Answers'
    }
  },
  
  // ترجمات البث المباشر والدردشة
  liveSession: {
    title: {
      ar: 'العنوان',
      en: 'Title'
    },
    description: {
      ar: 'الوصف',
      en: 'Description'
    },
    instructor: {
      ar: 'المدرب',
      en: 'Instructor'
    },
    course: {
      ar: 'الدورة',
      en: 'Course'
    },
    startTime: {
      ar: 'وقت البدء',
      en: 'Start Time'
    },
    endTime: {
      ar: 'وقت الانتهاء',
      en: 'End Time'
    },
    status: {
      ar: 'الحالة',
      en: 'Status'
    },
    active: {
      ar: 'نشطة',
      en: 'Active'
    },
    scheduled: {
      ar: 'مجدولة',
      en: 'Scheduled'
    },
    completed: {
      ar: 'مكتملة',
      en: 'Completed'
    },
    cancelled: {
      ar: 'ملغاة',
      en: 'Cancelled'
    },
    createSession: {
      ar: 'إنشاء جلسة جديدة',
      en: 'Create New Session'
    },
    editSession: {
      ar: 'تعديل الجلسة',
      en: 'Edit Session'
    },
    deleteSession: {
      ar: 'حذف الجلسة',
      en: 'Delete Session'
    },
    sessionCreated: {
      ar: 'تم إنشاء الجلسة بنجاح',
      en: 'Session created successfully'
    },
    sessionUpdated: {
      ar: 'تم تحديث الجلسة بنجاح',
      en: 'Session updated successfully'
    },
    sessionDeleted: {
      ar: 'تم حذف الجلسة بنجاح',
      en: 'Session deleted successfully'
    },
    joinSession: {
      ar: 'انضمام إلى الجلسة',
      en: 'Join Session'
    },
    leaveSession: {
      ar: 'مغادرة الجلسة',
      en: 'Leave Session'
    },
    participants: {
      ar: 'المشاركون',
      en: 'Participants'
    },
    chat: {
      ar: 'الدردشة',
      en: 'Chat'
    },
    sendMessage: {
      ar: 'إرسال',
      en: 'Send'
    },
    typeMessage: {
      ar: 'اكتب رسالتك هنا...',
      en: 'Type your message here...'
    },
    microphoneOn: {
      ar: 'تشغيل الميكروفون',
      en: 'Microphone On'
    },
    microphoneOff: {
      ar: 'إيقاف الميكروفون',
      en: 'Microphone Off'
    },
    cameraOn: {
      ar: 'تشغيل الكاميرا',
      en: 'Camera On'
    },
    cameraOff: {
      ar: 'إيقاف الكاميرا',
      en: 'Camera Off'
    },
    screenShareStart: {
      ar: 'بدء مشاركة الشاشة',
      en: 'Start Screen Sharing'
    },
    screenShareStop: {
      ar: 'إيقاف مشاركة الشاشة',
      en: 'Stop Screen Sharing'
    },
    recordingOn: {
      ar: 'التسجيل قيد التشغيل',
      en: 'Recording On'
    },
    recordingOff: {
      ar: 'التسجيل متوقف',
      en: 'Recording Off'
    },
    sessionJoined: {
      ar: 'انضم إلى الجلسة',
      en: 'joined the session'
    },
    sessionLeft: {
      ar: 'غادر الجلسة',
      en: 'left the session'
    }
  },
  
  // ترجمات لوحة التحكم
  dashboard: {
    welcome: {
      ar: 'مرحباً بك في منصة الصادق المستشار للاستشارات والتدريب',
      en: 'Welcome to Al-Sadeq Al-Mustashar Platform for Consulting and Training'
    },
    overview: {
      ar: 'نظرة عامة',
      en: 'Overview'
    },
    totalCourses: {
      ar: 'إجمالي الدورات',
      en: 'Total Courses'
    },
    totalStudents: {
      ar: 'إجمالي الطلاب',
      en: 'Total Students'
    },
    totalInstructors: {
      ar: 'إجمالي المدربين',
      en: 'Total Instructors'
    },
    activeSessions: {
      ar: 'الجلسات النشطة',
      en: 'Active Sessions'
    },
    recentActivities: {
      ar: 'الأنشطة الأخيرة',
      en: 'Recent Activities'
    },
    upcomingSessions: {
      ar: 'الجلسات القادمة',
      en: 'Upcoming Sessions'
    },
    myCourses: {
      ar: 'دوراتي',
      en: 'My Courses'
    },
    myProgress: {
      ar: 'تقدمي',
      en: 'My Progress'
    },
    notifications: {
      ar: 'الإشعارات',
      en: 'Notifications'
    },
    viewAll: {
      ar: 'عرض الكل',
      en: 'View All'
    }
  },
  
  // ترجمات الملف الشخصي
  profile: {
    title: {
      ar: 'الملف الشخصي',
      en: 'Profile'
    },
    personalInfo: {
      ar: 'المعلومات الشخصية',
      en: 'Personal Information'
    },
    accountSettings: {
      ar: 'إعدادات الحساب',
      en: 'Account Settings'
    },
    changePassword: {
      ar: 'تغيير كلمة المرور',
      en: 'Change Password'
    },
    currentPassword: {
      ar: 'كلمة المرور الحالية',
      en: 'Current Password'
    },
    newPassword: {
      ar: 'كلمة المرور الجديدة',
      en: 'New Password'
    },
    confirmNewPassword: {
      ar: 'تأكيد كلمة المرور الجديدة',
      en: 'Confirm New Password'
    },
    updateProfile: {
      ar: 'تحديث الملف الشخصي',
      en: 'Update Profile'
    },
    profileUpdated: {
      ar: 'تم تحديث الملف الشخصي بنجاح',
      en: 'Profile updated successfully'
    },
    passwordChanged: {
      ar: 'تم تغيير كلمة المرور بنجاح',
      en: 'Password changed successfully'
    },
    avatar: {
      ar: 'الصورة الشخصية',
      en: 'Avatar'
    },
    uploadAvatar: {
      ar: 'تحميل صورة',
      en: 'Upload Avatar'
    },
    removeAvatar: {
      ar: 'إزالة الصورة',
      en: 'Remove Avatar'
    },
    language: {
      ar: 'اللغة',
      en: 'Language'
    },
    arabic: {
      ar: 'العربية',
      en: 'Arabic'
    },
    english: {
      ar: 'الإنجليزية',
      en: 'English'
    }
  },
  
  // ترجمات الفوتر
  footer: {
    copyright: {
      ar: 'جميع الحقوق محفوظة © الصادق المستشار للاستشارات والتدريب',
      en: 'All rights reserved © Al-Sadeq Al-Mustashar for Consulting and Training'
    },
    termsOfService: {
      ar: 'شروط الخدمة',
      en: 'Terms of Service'
    },
    privacyPolicy: {
      ar: 'سياسة الخصوصية',
      en: 'Privacy Policy'
    },
    contactUs: {
      ar: 'اتصل بنا',
      en: 'Contact Us'
    },
    language: {
      ar: 'اللغة',
      en: 'Language'
    }
  }
};

// دالة مساعدة للحصول على الترجمة
export const getTranslation = (key, language) => {
  const keys = key.split('.');
  let value = translations;
  
  for (const k of keys) {
    if (value[k]) {
      value = value[k];
    } else {
      return key; // إرجاع المفتاح إذا لم يتم العثور على الترجمة
    }
  }
  
  return value[language] || key;
};

export default LanguageContext;
